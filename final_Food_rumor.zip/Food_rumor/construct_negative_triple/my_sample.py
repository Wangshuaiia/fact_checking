'''
定义采样函数，可以在训练的时候直接采样。（在这里定义主要是起到测试的作用）
@author: Shuai Wang
Date:2019.9.25
'''
import torch.utils.data as Data
from torch.utils.data import DataLoader
import json
import numpy as np
import random

#合并训练集：训练集需要将正负样本合在一起
def construct_train_dataset_and_label():
    '''
    把正负样本合并在一起，标签也按照其先后顺序合并
    合并后的格式[[s,r,t]...], 标签：numpy格式
    :return:
    '''
    train_list = []
    with open("train_construct_negative_triple", encoding='utf-8', mode='r') as f:
        train_neg_list = json.load(f)
    # print(len(train_neg_list))
    # print("读取：", train_neg_list)
    for triple_ in train_neg_list:
        train_list.append(triple_)

    with open("../process_to_OpenKE_format/train2id.txt", encoding='utf-8', mode='r') as f:
        # f_train_pos = json.load(f)
        train_pos_list = f.readlines()
    # print(train_pos_list)
    # print(len(train_pos_list))
    for line in train_pos_list:
        words = line.split()
        try:
            triple_middle = []
            triple_middle.append(words[0])
            triple_middle.append(words[1])
            triple_middle.append(words[2])
            train_list.append(triple_middle)
        except IndexError:
            pass
    print(train_list)
    print(len(train_list))
    train_label = np.append(np.ones(len(train_neg_list), int), np.zeros((len(train_pos_list)-1), int))
    print(train_label)
    print(len(train_label))
    return train_list, train_label

class myData(Data.Dataset):
    def __init__(self):
        self.train_data, self.train_label = construct_train_dataset_and_label()

    def __getitem__(self, index):
        x, y = [self.train_data[index][0], self.train_data[index][1], self.train_data[index][2]], self.train_label[index]
        return x, y
    def __len__(self):
        return len(self.train_label)

if __name__ == '__main__':
    dataset = myData()
    loader = DataLoader(dataset, batch_size=5, shuffle=True)
    for epoch in range(2):
        for step, (batch_x, batch_y) in enumerate(loader):
            print('Epoch: ', epoch, '| Step: ', step, '| batch x: ',
                  batch_x, '| batch y: ', batch_y)
            print(type(batch_x[0]))
            print(list(batch_x[1]))
            print(batch_x[2])
