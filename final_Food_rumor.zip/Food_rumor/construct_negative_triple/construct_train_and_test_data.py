'''
构造用于foodRumor训练和测试数据集，包括数据和标签。
需要构造的包括三个部分：
    1.训练集：包括构造的负样本train_construct_negative_triple(5287), 和正样本 train2id(4929)
    2.valid集：包括构造的负样本valid_construct_negative_triple(1000), 和正样本 valid2id(995)
    3.test集合：来自谣言的负样本 negative_rumor_test2id.txt（200）, 和正样本 test2id(200) //需要选出来200个
label:正样本（正确三元组）：0      负样本（谣言）：1
@author: Shuai Wang
Date:2019.9.25
'''
import json
import numpy as np
import random
#合并训练集：训练集需要将正负样本合在一起
def construct_train_dataset_and_label():
    '''
    把正负样本合并在一起，标签也按照其先后顺序合并
    合并后的格式[[s,r,t]...], 标签：numpy格式
    :return:
    '''
    train_list = []
    with open("train_construct_negative_triple", encoding='utf-8', mode='r') as f:
        train_neg_list = json.load(f)
    # print(len(train_neg_list))
    # print("读取：", train_neg_list)
    for triple_ in train_neg_list:
        train_list.append(triple_)

    with open("../process_to_OpenKE_format/train2id.txt", encoding='utf-8', mode='r') as f:
        # f_train_pos = json.load(f)
        train_pos_list = f.readlines()
    # print(train_pos_list)
    # print(len(train_pos_list))
    for line in train_pos_list:
        words = line.split()
        try:
            triple_middle = []
            triple_middle.append(words[0])
            triple_middle.append(words[1])
            triple_middle.append(words[2])
            train_list.append(triple_middle)
        except IndexError:
            pass
    print(train_list)
    print(len(train_list))
    train_label = np.append(np.ones(len(train_neg_list), int), np.zeros((len(train_pos_list)-1), int))
    print(train_label)
    print(len(train_label))
    return train_list, train_label

#valid数据集，正负样本分开
def construct_valid_dataset_and_label():
    '''
    可能不需要label
    :return:
    '''
    with open("valid_construct_negative_triple", encoding='utf-8', mode='r') as f:
        valid_neg_list = json.load(f)
    print(len(valid_neg_list))
    print("读取：", valid_neg_list)
    with open("../process_to_OpenKE_format/valid2id.txt", encoding='utf-8', mode='r') as f:
        valid_pos_list_read_from_file = f.readlines()
    # print(len(valid_pos_list_read_from_file))
    # print("读取：", valid_pos_list_read_from_file)
    valid_pos_list = []
    for line in valid_pos_list_read_from_file:
        words = line.split()
        try:
            triple_middle = []
            triple_middle.append(words[0])
            triple_middle.append(words[1])
            triple_middle.append(words[2])
            valid_pos_list.append(triple_middle)
        except IndexError:
            pass
    print(valid_pos_list)
    print(len(valid_pos_list))
    return valid_pos_list, valid_neg_list


#test数据集，正负样本分开
def construct_test_dataset_and_label():
    with open("negative_rumor_test2id.txt", encoding='utf-8', mode='r') as f:
        test_neg_list_read_from_file = f.readlines()
    print(test_neg_list_read_from_file)
    print(len(test_neg_list_read_from_file))
    test_neg_list = []
    for line in test_neg_list_read_from_file:
        words = line.split()
        try:
            triple_middle = []
            triple_middle.append(words[0])
            triple_middle.append(words[1])
            triple_middle.append(words[2])
            test_neg_list.append(triple_middle)
        except IndexError:
            pass
    print(test_neg_list)
    print(len(test_neg_list))

    #从test2id.txt 中选取和负样本个数一样的正样本（177个）
    with open("../process_to_OpenKE_format/test2id.txt", encoding='utf-8', mode='r') as f:
        test_pos_list_read_from_file = f.readlines()
    # print(test_pos_list_read_from_file)
    # print(len(test_pos_list_read_from_file))

    test_pos_list_middle = random.sample(test_pos_list_read_from_file, len(test_neg_list))
    test_pos_list = []
    for line in test_pos_list_middle:
        words = line.split()
        try:
            triple_middle = []
            triple_middle.append(words[0])
            triple_middle.append(words[1])
            triple_middle.append(words[2])
            test_pos_list.append(triple_middle)
        except IndexError:
            pass
    with open("my_test2id.txt", encoding='utf-8', mode='w') as fw:
        json.dump(test_pos_list,fw)
    print(test_pos_list)
    print(len(test_pos_list))
    return test_pos_list, test_neg_list

if __name__ == '__main__':
    construct_train_dataset_and_label()
    construct_valid_dataset_and_label()
    construct_test_dataset_and_label()
