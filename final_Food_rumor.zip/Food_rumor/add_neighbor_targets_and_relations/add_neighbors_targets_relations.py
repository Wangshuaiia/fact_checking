'''
把FoodRumor训练和测试需要的所有的三元组数据集，添加一个relation数据集。
@author: Shuai Wang
Date:2019.9.27
'''
import json
import numpy as np
#读取所有的需要的数据集
#训练样本


def construct_valid_dataset_and_label():

    with open("../benchmarks/foodRumor/valid_construct_negative_triple", encoding='utf-8', mode='r') as f:
        valid_neg_list = json.load(f)
    with open("../benchmarks/foodRumor/valid2id.txt", encoding='utf-8', mode='r') as f:
        valid_pos_list_read_from_file = f.readlines()
    valid_pos_list = []
    for line in valid_pos_list_read_from_file:
        words = line.split()
        try:
            triple_middle = []
            triple_middle.append(words[0])
            triple_middle.append(words[1])
            triple_middle.append(words[2])
            valid_pos_list.append(triple_middle)
        except IndexError:
            pass
    # print(valid_pos_list)
    print("len(valid_pos_list):", len(valid_pos_list))
    print("len(valid_neg_list):", len(valid_neg_list))
    return valid_pos_list, valid_neg_list


def construct_test_dataset_and_label():
    with open("../benchmarks/foodRumor/negative_rumor_test2id.txt", encoding='utf-8', mode='r') as f:
        test_neg_list_read_from_file = f.readlines()
    test_neg_list = []
    for line in test_neg_list_read_from_file:
        words = line.split()
        try:
            triple_middle = []
            triple_middle.append(words[0])
            triple_middle.append(words[1])
            triple_middle.append(words[2])
            test_neg_list.append(triple_middle)
        except IndexError:
            pass
    # print(test_neg_list)
    # print(len(test_neg_list))

    with open("../benchmarks/foodRumor/my_test2id.txt", encoding='utf-8', mode='r') as f:
        test_pos_list_read_from_file = json.load(f)
        # test_pos_list_read_from_file = f.readlines()

    # test_pos_list_middle = random.sample(test_pos_list_read_from_file, len(test_neg_list))
    test_pos_list = []
    for words in test_pos_list_read_from_file:
        try:
            triple_middle = []
            triple_middle.append(words[0])
            triple_middle.append(words[1])
            triple_middle.append(words[2])
            test_pos_list.append(triple_middle)
        except IndexError:
            pass
    # print(test_pos_list)
    print("len(test_pos_list):", len(test_pos_list))
    print("len(test_neg_list):", len(test_neg_list))
    return test_pos_list, test_neg_list


def construct_train_dataset_and_label():
    train_list = []
    with open("../construct_negative_triple/train_construct_negative_triple", encoding='utf-8', mode='r') as f:
        train_neg_list = json.load(f)

    for triple_ in train_neg_list:
        train_list.append(triple_)

    with open("../process_to_OpenKE_format/train2id.txt", encoding='utf-8', mode='r') as f:
        train_pos_list_middle = f.readlines()
        train_pos_list = []
        for line in train_pos_list_middle:
            words = line.split()
            try:
                triple_middle = []
                triple_middle.append(int(words[0]))
                triple_middle.append(int(words[1]))
                triple_middle.append(int(words[2]))
                train_pos_list.append(triple_middle)
            except IndexError:
                pass

    train_list.extend(train_pos_list)
    # print("train_neg_list:", train_neg_list)
    # print("train_pos_list:", train_pos_list)
    # print("len(train_list):", len(train_list))

    neg_entity = []
    for triple_ in train_neg_list:
        source = triple_[0]
        neg_entity.append(source)

    train_label = np.append(-np.ones(len(train_neg_list), dtype=np.float32), np.ones((len(train_pos_list)-1), dtype=np.float32))
    # print("train_label:", train_label)
    # print("len(train_label):", len(train_label))
    train_entTotal = set()
    relTotal = set()
    for triple_ in train_list:
        # print(triple_)
        train_entTotal.add(int(triple_[0]))
        train_entTotal.add(int(triple_[1]))
        relTotal.add(int(triple_[2]))
    ent_total_num = len(train_entTotal)
    rel_total_num = len(relTotal)
    print("train_entTotal:", train_entTotal)
    print(max(train_entTotal))
    print("relTotal:", relTotal)
    print(max(relTotal))
    # print(train_list)
    # print("len(train_neg_list):", len(train_neg_list))
    # print("len(train_pos_list):", len(train_pos_list))
    # print("len(ent_total_num):", ent_total_num)
    # print("len(rel_total_num):", rel_total_num)
    return train_list, train_label, ent_total_num, rel_total_num, train_entTotal, train_pos_list, neg_entity


def padding(input_list, padding_scale, padding_num):
    '''
    padding函数
    :param padding_scale: padding到的数值
    :param padding_num: 用于填充的数字
    :return: padding后的list
    '''

    if len(input_list) == padding_scale:
        target_neighbor_padding = input_list
        pass
    elif len(input_list) > padding_scale:
        target_neighbor_padding = input_list[:padding_scale] # 多了就截断
    else: # 少了padding
        padding_list = []
        for i in range(padding_scale-len(input_list)):
            padding_list.append(padding_num)
        target_neighbor_padding = []
        target_neighbor_padding.extend(input_list)
        # target_neighbor_padding = input_list
        target_neighbor_padding.extend(padding_list)

    return target_neighbor_padding


# 针对各个数据集来建立新的neighbor数据集
def construct_neighbor_dataset(triple_list):
    '''
    输入是triple_list,输出是相关的list
    若不够，需要补全，则在entity中最大的id上加一个数。注意：不是在 ent_total_num.加一个数。因为 ent_total_num = 2881，而id中最大的数是3053 /// 3056
    在embedding矩阵中，其对应的embedding是0.
    :param triple_list:
    :return:
    '''
    # --------------后期需要注释掉------------------
    train_list, train_label, ent_total_num, rel_total_num, entTotal, train_pos_list, neg_entity = \
        construct_train_dataset_and_label()
    # print("neg_entity:", neg_entity)
    triple_list = train_list # 测试用，后期删
    # --------------后期需要注释掉------------------
    with open("target_neighbor_dict", encoding='utf-8', mode='r') as f:
        target_neighbor_dict = json.load(f)

    with open("relation_neighbor_dict", encoding='utf-8', mode='r') as f:
        relation_neighbor_dict = json.load(f)

    return_padded_relation = []
    return_padded_target = []
    print("len(triple_list):", len(triple_list))
    for triple_ in triple_list:
        source = str(triple_[0])
        try:
            target_neighbor = target_neighbor_dict[source]  # 正面的知识图谱并不完全包含所有的负面source，有些source在知识图谱中没有
            padded_list_target = padding(target_neighbor, padding_scale=15, padding_num=3056)
            padded_list_target.sort(reverse=False)
        except KeyError:
            # print(type(source), source)
            padded_list_target = padding([int(source)], padding_scale=15, padding_num=3056)
            padded_list_target.sort(reverse=False)
            # print("padded_list_target:", padded_list_target)

        rel = triple_[2]
        try:
            relation_neighbor = relation_neighbor_dict[source]
            padded_list_relation = padding(relation_neighbor, padding_scale=5, padding_num=84)
            padded_list_relation.sort(reverse=False)
        except KeyError:
            # print(type(rel), rel)
            padded_list_relation = padding([int(rel)], padding_scale=5, padding_num=84)
            padded_list_relation.sort(reverse=False)
            # print("padded_list_relation:", padded_list_relation)
        # print(padded_list_target)
        # print(padded_list_relation)
        return_padded_target.append(padded_list_target)
        return_padded_relation.append(padded_list_relation)
    # print("len(return_padded_target):", len(return_padded_target))
    # print("len(return_padded_relation):", len(return_padded_relation))
        # try:
        #     target_neighbor = target_neighbor_dict[source]  # 正面的知识图谱并不完全包含所有的负面source，有些source在知识图谱中没有
        #     relation_neighbor = relation_neighbor_dict[source]
        #     '''没有neighbor的就把他自己本身添加进去'''
        #     #padding
        #     '''target padding到15， relation padding到5 '''
        #
        #     # print("target_neighbor:", target_neighbor)
        #     padded_list_target = padding(target_neighbor, padding_scale=15, padding_num=3056)
        #     padded_list_target.sort(reverse=False)
        #     padded_list_relation = padding(relation_neighbor, padding_scale=5, padding_num=84)
        #     padded_list_relation.sort(reverse=False)
        #     # print("padded_list_relation:", padded_list_relation)
        #     # print("padded_list:", padded_list)
        #
        # except KeyError:
        #     print("source:", source)
        #     padding([source], padding_scale=15, padding_num=3056)
        #     continue
    return return_padded_target, return_padded_relation
    # return padded_list_relation


if __name__ == '__main__':
    triple_list = []
    construct_neighbor_dataset(triple_list)

