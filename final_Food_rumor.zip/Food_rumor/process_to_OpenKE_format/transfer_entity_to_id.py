'''
把entity转换成对应的id
@author：Shuai Wang
2019.9.16
'''
import json
import collections
import random

#读取所有的三元组（positive 和 negative）
fw_set = open("../KnowledgeGraph/overall_negative_triple", encoding='utf-8', mode='r') #存储的谣言三元组，包括食物相克和政府辟谣网站上面的
negative_list = json.load(fw_set)
fw_set.close()
# print(len(negative_list))
# print("读取：", negative_list)

fw_set = open("../crawler/overall_meishiChina_triple_list", encoding='utf-8', mode='r')
positive_list = json.load(fw_set)
fw_set.close()
# print(len(positive_list))
# print("读取：", positive_list)

overall_list = positive_list + negative_list
#------------统计所有的词频-------------
#将所有的head和tail集中在一个list中
entity_list = []
relation_list = []
for triple_ in overall_list:
    entity_list.append(triple_[0])
    entity_list.append(triple_[2])
    relation_list.append(triple_[1])

#统计词频
frequency_entity = collections.Counter(entity_list)
frequency_relation = collections.Counter(relation_list)
# print(len(overall_list))
# print(len(positive_list))
# print(len(negative_list))
# print(len(frequency_entity))
# print(frequency_entity)
# print(len(frequency_relation))
# print(frequency_relation)


def statistic_head():
    '''
    统计所有三元组中的头实体（食物）的个数，并存储到字典
    本函数测试完就没什么用了
    Date: 2019.10.23
    :return:
    '''
    head_list = []
    for triple_ in overall_list:
        head_list.append(triple_[0])
    head_list = list(set(head_list))
    print(head_list)
    print(len(head_list))
    with open("../0_food_nutrition_process//all_head_list", encoding='utf-8', mode='w') as fw:
        for head in head_list:
            fw.write(head + '\n')


# statistic_head()


#--------------------编号-------------------------
#按照词频从高到低输出
entity_dict = dict()
num = 0 #编号
for entity in frequency_entity:
    # print(entity, '\t', num)
    entity_dict[entity] = num
    num += 1

relation_dict = dict()
num = 0
for relation in frequency_relation:
    # print(relation, '\t', num)
    relation_dict[relation] = num
    num += 1

with open("entity2id.txt", encoding='utf-8', mode='w') as f:
    write_string = str(len(entity_dict)) + '\n'
    f.write(write_string)
    for entity in entity_dict.keys():
        write_string = str(entity) + '\t' + str(entity_dict[entity]) + '\n'
        f.write(write_string)

with open("relation2id.txt", encoding='utf-8', mode='w') as f:
    write_string = str(len(relation_dict)) + '\n'
    f.write(write_string)
    for relation in relation_dict.keys():
        write_string = str(relation) + '\t' + str(relation_dict[relation]) + '\n'
        f.write(write_string)

#-------------------将所有的三元组转化为id----------------------

positive_triple_id = [] #id形式的triple
for triple_ in positive_list:
    id_triple = []
    id_triple.append(entity_dict[triple_[0]])
    id_triple.append(relation_dict[triple_[1]])
    id_triple.append(entity_dict[triple_[2]]) #这里一定要注意，三元组的个格式形式是错误的,relation要放在最后
    positive_triple_id.append(id_triple)

#全局变量

# --------------在这里对所有的负样本和选580个验证集中的正样本，来构造 头实体 和 尾实体 的neighbor-----------------
'''
@code: 用于做谣言的可解释性，选出所有头实体和尾实体的集合作为evidence的候选集合
@Date:2019.11.27
'''
head_neighbor_dict = dict()  # 头实体的neighbor，即里面存储的都是尾实体
tail_neighbor_dict = dict()  # 尾实体的neighbor，即里面存储的都是头实体
'''构造好head 和tail 的neighbor的字典，在其他程序中直接使用字典即可'''
for triple_ in positive_triple_id:
    source = triple_[0]
    target = triple_[2]
    relation = triple_[1]
    if source in head_neighbor_dict.keys():
        middle_neighbor = head_neighbor_dict[source]
        if target not in middle_neighbor:
            middle_neighbor.append(target)
            head_neighbor_dict[source] = middle_neighbor
    else:
        head_neighbor_dict[source] = [target]

    if target in tail_neighbor_dict.keys():
        middle_neighbor = tail_neighbor_dict[target]
        if source not in middle_neighbor:
            middle_neighbor.append(source)
            tail_neighbor_dict[target] = middle_neighbor
    else:
        tail_neighbor_dict[target] = [source]

# ----------------------------------------------------------------------------------------------------------------

# -------------------------------构造neighbor dict 和 relation dict------(训练时会用到)--------------------------------
'''这里只用positive的三元组来构造一个节点的entity'''
neighbor_dict = dict() #全局变量
neighbor_relation_dict = dict() #全局变量

for triple_ in positive_triple_id:
    print(triple_)
    source = triple_[0]
    target = triple_[2]
    relation = triple_[1]
    if source in neighbor_dict.keys():

        middle_neighbor = neighbor_dict[source]
        if target not in middle_neighbor:
            middle_neighbor.append(target)
            neighbor_dict[source] = middle_neighbor

        middle_relation = neighbor_relation_dict[source]
        if relation not in middle_relation:
            middle_relation.append(relation)
            neighbor_relation_dict[source] = middle_relation

    else:
        neighbor_dict[source] = [target]
        neighbor_relation_dict[source] = [relation]

print(neighbor_dict)
print(neighbor_relation_dict)
# 在这里构造neighbor的字典
with open("../add_neighbor_targets_and_relations//target_neighbor_dict", encoding='utf-8', mode='w') as fw:
    json.dump(neighbor_dict, fw)

with open("../add_neighbor_targets_and_relations//relation_neighbor_dict", encoding='utf-8', mode='w') as fw:
    json.dump(neighbor_relation_dict, fw)

# -------------------------------------------------------------------------------------

# count_list = []
# relation_count = []
# for source in neighbor_dict.keys():
#     middle_neighbor = neighbor_dict[source]
#     count_list.append(len(middle_neighbor))
#
#     middle_relation = relation_dict[source]
#     relation_count.append(len(middle_relation))
# count_rel = collections.Counter(relation_count)
# count = collections.Counter(count_list)
# print(count)
# print(count_rel)


negative_triple_id = []
for triple_ in negative_list:
    id_triple = []
    id_triple.append(entity_dict[triple_[0]])
    id_triple.append(relation_dict[triple_[1]])
    id_triple.append(entity_dict[triple_[2]])
    negative_triple_id.append(id_triple)

# def convert_triple_to_id(triple_list):
#     '''
#     把三元组转化为id的形式
#     :param triple_list: 一个三元组list，中间包含很多个三元组
#     :return:
#     '''
#     triple_list = [] #一会删
#     # for trip in triple_list:
#     #     id_triple = []
#     overal_middle_id_triple = []
#
#     for triple_ in overall_list:
#         id_triple = [] #每次把这个清空
#         id_triple.append(entity_dict[triple_[0]])
#         id_triple.append(relation_dict[triple_[1]])
#         id_triple.append(entity_dict[triple_[2]])
#         overal_middle_id_triple.append(id_triple)


'''应该按照正负的比例，从各自的正负中提取'''
def part_train_test():
    '''
    由于其中有重复的，所以筛选出对应的index，根据index提取训练测试和validation
    :return:
    '''
    test_negative_index = random.sample(range(len(negative_list)), int(len(negative_list)/6))
    validation_negative_index = random.sample(range(len(negative_list)), int(len(negative_list)/6))
    test_positive_index = random.sample(range(len(positive_list)), int(len(positive_list)/6))
    validation_positive_index = random.sample(range(len(positive_list)), int(len(positive_list)/6))
    train_positive_index = []
    train_negative_index = []
    '''没被选出的index当作train'''
    for index in range(len(positive_list)):
        if (index not in test_positive_index) and (index not in validation_positive_index):
            # positive_list[index]
            train_positive_index.append(index)

    for index in range(len(negative_list)):
        if (index not in test_negative_index) and (index not in validation_negative_index):
            train_negative_index.append(index)

    '''根据分好的index，把数据集分开'''
    train_negative_triple = []
    test_negative_triple = []
    validation_negative_triple = []
    train_positive_triple = []
    test_positive_triple = []
    validation_positive_triple = []

    for index in range(len(negative_list)):
        triple = negative_triple_id[index]
        if index in train_negative_index:
            train_negative_triple.append(triple)
        elif index in test_negative_index:
            test_negative_triple.append(triple)
        elif index in validation_negative_index:
            validation_negative_triple.append(triple)

    for index in range(len(positive_list)):
        triple = positive_triple_id[index]
        if index in train_positive_index:
            train_positive_triple.append(triple)
        elif index in test_positive_index:
            test_positive_triple.append(triple)
        elif index in validation_positive_index:
            validation_positive_triple.append(triple)
    print(len(train_negative_triple))
    print(train_negative_triple)
    print(len(test_negative_triple))
    print(test_negative_triple)
    print(len(validation_negative_triple))
    print(validation_negative_triple)

    '''将三元组id写入文件,目前只写入positive的'''
    with open("train2id.txt", encoding='utf-8', mode='w') as f:
        write_string = str(len(train_positive_triple)) + '\n'
        f.write(write_string)
        for triple_ in train_positive_triple: #这里需要把三元组每个都提出来
            write_string = str(triple_[0]) + ' ' + str(triple_[2]) + ' ' + str(triple_[1]) + '\n' #注意格式，relation应该在最后
            f.write(write_string)
        # write_string = str(len(positive_triple_id)) + '\n'  # 用整个知识图谱训练
        # for triple_ in positive_triple_id: #用整个知识图谱训练
        #     write_string = str(triple_[0]) + ' ' + str(triple_[2]) + ' ' + str(triple_[1]) + '\n' #注意格式，relation应该在最后
        #     f.write(write_string)
    with open("test2id.txt", encoding='utf-8', mode='w') as f:
        write_string = str(len(test_positive_triple)) + '\n'
        f.write(write_string)
        for triple_ in test_positive_triple: #这里需要把三元组每个都提出来
            # write_string = str(triple_[0]) + ' ' + str(triple_[1]) + ' ' + str(triple_[2]) + '\n'
            write_string = str(triple_[0]) + ' ' + str(triple_[2]) + ' ' + str(triple_[1]) + '\n'
            f.write(write_string)

    with open("valid2id.txt", encoding='utf-8', mode='w') as f:
        write_string = str(len(validation_positive_triple)) + '\n'
        f.write(write_string)
        for triple_ in validation_positive_triple: #这里需要把三元组每个都提出来
            # write_string = str(triple_[0]) + ' ' + str(triple_[1]) + ' ' + str(triple_[2]) + '\n'
            write_string = str(triple_[0]) + ' ' + str(triple_[2]) + ' ' + str(triple_[1]) + '\n'
            f.write(write_string)
    '''-------------将negative 负样本 也写入文件中-----------------------------------------'''
    with open("../construct_negative_triple//negative_rumor_train2id.txt", encoding='utf-8', mode='w') as f:
        #这里暂时先不写三元组的个数
        for triple_ in train_negative_triple:
            write_string = str(triple_[0]) + ' ' + str(triple_[2]) + ' ' + str(triple_[1]) + '\n'
            f.write(write_string)
    with open("../construct_negative_triple//negative_rumor_test2id.txt", encoding='utf-8', mode='w') as f:
        for triple_ in test_negative_triple:
            write_string = str(triple_[0]) + ' ' + str(triple_[2]) + ' ' + str(triple_[1]) + '\n'
            f.write(write_string)
    with open("../construct_negative_triple//negative_rumor_valid2id.txt", encoding='utf-8', mode='w') as f:
        for triple_ in validation_negative_triple:
            write_string = str(triple_[0]) + ' ' + str(triple_[2]) + ' ' + str(triple_[1]) + '\n'
            f.write(write_string)
    '''-----------------------------------------------------------------------------------'''
    return train_negative_triple, test_negative_triple, validation_negative_triple, \
           train_positive_triple, test_positive_triple, validation_positive_triple

if __name__ == '__main__':

    part_train_test()
