# 同时执行test1,test2
import time
import threading

def test1(arg1):
    print("启动任务1")
    print("任务1的参数为{}".format(arg1))
    time.sleep(5)
    print("结束任务1")

def test2(arg2):
    print("启动任务2")
    print("任务2的参数为{}".format(arg2))
    time.sleep(2)
    print("结束任务2")

def main():
    start_time = time.time()
    t1 = threading.Thread(target=test1,args=("ONE",))
    t2 = threading.Thread(target=test2,args=("TWO",))
    t1.start()
    t2.start()

    # 等待两个子线程结束再结束主线程
    t1.join()
    t2.join()

    end_time = time.time()
    total_time = end_time - start_time
    print("所有任务结束，总耗时为：{}".format(total_time))

if __name__ == "__main__":
    main()