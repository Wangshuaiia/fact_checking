'''
2019.8.17
@author: Shuai Wang
爬取食物列表，组成一个食物清单的集合
'''
from bs4 import BeautifulSoup
from urllib import request
import re
import json

#检验是否含有中文字符
def is_contains_chinese(strs):
    for _char in strs:
        if '\u4e00' <= _char <= '\u9fa5':
            return True
    return False


def data_process(line):
    '''
    对爬取的数据进行处理，得到食物清单，知识针对网站："http://www.shoumm.com"
    :param line: 输入的是一行爬取的文本
    :return:
    '''
    #除去没用的行数
    # if line.__contains__("热量(大卡)/可食部分(克)") or line.__contains__("食品名称"): #这两个是在这里有规律的
    #     return ''
    line = str(line)
    # print("line:",line)
    if not line.__contains__("#000000"):
        # print("不包含：",line)
        return ''
    elif line.__contains__("食品名称</font>"):
        # print("包含：", line)
        return ''
    #除去不含中文的行
    if not is_contains_chinese(line):
        return ''
    #删去< >字符串，除了<br/>, 因为这里比较规则，所以可以简便这么抽
    line = line.replace('<font color="#000000" style="font-size: 14px">', '')
    line = line.replace('</font>', '')
    #删去所有的()，及其其中的内容
    p1 = re.compile(r'\((.*?)\)', re.S)
    seg_line = re.sub(p1, '', line)
    line = re.sub(' +', '', seg_line)
    seg_line = line.replace(' ','') #删去空格和换行
    seg_line = seg_line.replace('\r\n','')
    # print(seg_line)
    #按照<br/>进行split
    seg_list = seg_line.split('<br/>')
    # print(seg_list)
    return seg_list


if __name__ == '__main__':
    html = request.urlopen("http://www.shoumm.com")
    bs = BeautifulSoup(html, "lxml")  # 将html对象转化为BeautifulSoup对象
    # print(type(bs))
    all_food = bs.find_all('font') #得到的all_food中含有很多的br
    # print(all_food.get_text('\n', '<br/>'))
    all_food_list = []
    i = 0
    for string in all_food:
        i += 1
        # print(i, string)
        seg_list = data_process(string)
        try:
            all_food_list = all_food_list + seg_list
        except TypeError:
            pass
    print(len(all_food_list))
    # all_food_set = set(all_food_list)
    print(all_food_list)

    #讲list存储为json
    # fw_set = open("food_list_set", encoding='utf-8', mode='w')
    # json.dump(all_food_list, fw_set)
    # fw_set.close()

    #把list从json中读取
    fw_set = open("food_list_set", encoding='utf-8', mode='r')
    f_json = json.load(fw_set)
    fw_set.close()
    print(f_json)
