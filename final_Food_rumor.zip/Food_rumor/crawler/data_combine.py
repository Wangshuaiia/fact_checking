'''
2019.8.24
@author: Shuai Wang
对于“美食中国”数据集，因为爬虫爬取source和target的时候有程序中间断的现象，所以在这里把多个断掉的合成在一起
'''
import json

def combine_target_complete_list():
    '''
    合成“美食中国”中的“食用功效”list。没有删去relation版本的
    :return:
    '''
    overall_target_gongxiao_list = []
    # 把list从json中读取
    fw_set = open("meishiChina_target_gongxiao_complete_2500", encoding='utf-8', mode='r')
    f_2500 = json.load(fw_set)
    fw_set.close()
    print("读取：", f_2500)
    print("读取：", len(f_2500))

    # 把list从json中读取
    fw_set = open("meishiChina_target_gongxiao_complete_5000", encoding='utf-8', mode='r')
    f_5000 = json.load(fw_set)
    fw_set.close()
    print("读取：", f_5000)
    print("读取：", len(f_5000))

    overall_target_gongxiao_list_middle = f_2500 + f_5000
    overall_target_gongxiao_list = sorted(overall_target_gongxiao_list_middle, key=lambda i:len(i), reverse=True) #对其进行排序
    print(overall_target_gongxiao_list)
    print(len(overall_target_gongxiao_list))
    # 将list存储为json
    fw_set = open("overall_complete_meishiChina_target_gongxiao", encoding='utf-8', mode='w')  # 存储source
    json.dump(overall_target_gongxiao_list, fw_set)
    fw_set.close()

def combine_target_delete_list():
    '''
    合成“美食中国”中的“食用功效”list。  删去relation版本的
    :return:
    '''
    overall_target_gongxiao_list = []
    # 把list从json中读取
    fw_set = open("meishiChina_target_gongxiao_1500", encoding='utf-8', mode='r')
    f_2500 = json.load(fw_set)
    fw_set.close()
    print("读取：", f_2500)
    print("读取：", len(f_2500))

    # 把list从json中读取
    fw_set = open("meishiChina_target_gongxiao_3143", encoding='utf-8', mode='r')
    f_5000 = json.load(fw_set)
    fw_set.close()
    print("读取：", f_5000)
    print("读取：", len(f_5000))

    overall_target_gongxiao_list_middle = f_2500 + f_5000
    overall_target_gongxiao_list = sorted(overall_target_gongxiao_list_middle, key=lambda i: len(i),
                                          reverse=True)  # 对其进行排序
    print(overall_target_gongxiao_list)
    print(len(overall_target_gongxiao_list))
    # 将list存储为json
    fw_set = open("overall_delete_relation_meishiChina_target_gongxiao", encoding='utf-8', mode='w')  # 存储source
    json.dump(overall_target_gongxiao_list, fw_set)
    fw_set.close()

if __name__ == '__main__':
    #合成“美食中国”中的“食用功效”list。没有删去relation版本的
    combine_target_complete_list()
    #合成“美食中国”中的“食用功效”list。  删去relation版本的
    combine_target_delete_list()