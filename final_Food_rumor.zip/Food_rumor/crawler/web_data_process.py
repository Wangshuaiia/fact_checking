'''
2019.8.12
@author: Shuai Wang
@code: 使用json处理和读取爬取网页的内容
'''
import json
import re

f = open("web_data_test", encoding="utf-8", mode='r').readlines() #读取网页爬取的内容
print(f[0])
x = re.findall(r'[^()]+', f[0])[1] #正则表达式提取小括号中间的内容,提取后为json
j_obj = json.loads(x) #json格式
print(j_obj["data"])
j_data = j_obj["data"]["list"]
print(j_data)

# f = open("D:\\Dataset\\rumors\\food_Rumor\\")
for one_obj in j_data:
    title = one_obj["Title"]
    url = one_obj["LinkUrl"]
    abstract = one_obj["Abstract"]
print(j_data[0])
print(j_data[0]["Title"])

