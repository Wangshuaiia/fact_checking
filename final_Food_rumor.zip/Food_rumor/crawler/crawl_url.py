'''
2019.8.12
@author: Shuai Wang
@code: 爬取食品相关的谣言数据,并进行后续的处理，保存title，abstract，内容
'''
from urllib.request import urlopen#用于获取网页
from urllib.request import Request
from bs4 import BeautifulSoup#用于解析网页
import urllib
import json
import re

'''
全局变量
'''
url_list = []
abstract_list = []
title_list = []
fw_url = open("D:\\Dataset\\rumors\\food_Rumor\\China_food_url.txt", encoding="utf-8", mode="w")  #把单个谣言的url（273个）写到该文件之中
fw_content = open("D:\\Dataset\\rumors\\food_Rumor\\China_food_content.txt", encoding="utf-8", mode="w") #把谣言的内容写到文件中

def crawl_web(http_url):
    '''
    :param http_url: 待爬的网址
    :return: 爬取的网页内容
    '''
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0'}
    req = Request(
        url=http_url,
        headers=headers)
    html = urlopen(req)
    # print(html)
    bsObj = BeautifulSoup(html, 'html.parser')
    print(bsObj)
    return bsObj


def process_url(i):
    '''
    处理得到有用的url
    @:return url, pagenum
    '''
    forehead = "http://da.wa.news.cn/nodeart/page?nid=11158879&pgnum="
    after_body = "&cnt=16&attr=&tp=1&orderby=1&callback=jQuery112408135924745464322_1565605737294&_=1565605737321"
    num = int(i)
    http_url = forehead + str(num) + after_body
    return http_url

def process_web_data(text_crawl):
    '''
    对爬取的内容进行处理，分离出 title，abstract，url
    :param text_crawl:爬取的文本内容，将 title，abstract，url 添加到全局变量
    :return: title，abstract，url，每次返回爬取的一组
    '''

    x = re.findall(r'[^()]+', str(text_crawl))[1]  # 正则表达式提取小括号中间的内容,提取后为json
    j_obj = json.loads(x)  # json格式
    # print(j_obj["data"])
    j_data = j_obj["data"]["list"]
    # print(j_data)
    for one_obj in j_data:
        title = one_obj["Title"]
        url_text = one_obj["LinkUrl"]
        abstract = one_obj["Abstract"]
        #在这里应该对数据进行保存
        title_list.append(title)
        url_list.append(url_text)
        abstract_list.append(abstract)
        fw_url.write(url_text.strip() + '\n')


def extract_content(single_url):
    '''
    根据url从网上爬取谣言对应网页的全部信息，并把其中的主体部分筛选出来
    :param: url: 单个谣言的url
    :return:
    '''
    html = urlopen(single_url)
    bs = BeautifulSoup(html, "lxml")    #将html对象转化为BeautifulSoup对象
    content_body = bs.body.select("div[class='con_txt']")
    content = content_body[0].get_text()
    #需要把content写入文件
    fw_content.writelines(content.strip())
    fw_content.write('\n')


if __name__ == '__main__':
    for page_number in range(1,19):
        url = process_url(page_number)
        text_crawl = crawl_web(url)
        process_web_data(text_crawl)
    fw_url.close()
    # print(len(url_list))
    for i in range(270, len(url_list)):
        fw_content.write(str(i) + title_list[i].strip() + '\n') #写题目
        if abstract_list[i]:
            fw_content.write(abstract_list[i].strip() + '\n') #写摘要
        try:
            extract_content(url_list[i]) #写内容
        except urllib.error.URLError:
            pass
        fw_content.write('---------------------------------------------------------------------------------------\n')#写分割线
        # quit()
    fw_content.close()