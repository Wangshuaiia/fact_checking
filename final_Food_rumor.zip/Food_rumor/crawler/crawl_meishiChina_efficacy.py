'''
2019.8.22
@author: Shuai Wang
根据爬取的url，提取每个网页链接里面的食物功效
'''
from urllib.request import urlopen#用于获取网页
from urllib.request import Request
import urllib3
from bs4 import BeautifulSoup#用于解析网页
import urllib
import json
import re
import chardet
import requests
import json
import random
import time
from fake_useragent import UserAgent
import eventlet #导入eventlet这个模块


eventlet.monkey_patch()#必须加这条代码, 防止爬虫卡在某一条程序上

#爬虫用的 headers 池
USER_AGENT_LIST = [
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; AcooBrowser; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
    "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; Acoo Browser; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506)",
    "Mozilla/4.0 (compatible; MSIE 7.0; AOL 9.5; AOLBuild 4337.35; Windows NT 5.1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)",
    "Mozilla/5.0 (Windows; U; MSIE 9.0; Windows NT 9.0; en-US)",
    "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 2.0.50727; Media Center PC 6.0)",
    "Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 1.0.3705; .NET CLR 1.1.4322)",
    "Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; InfoPath.2; .NET CLR 3.0.04506.30)",
    "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.3 (Change: 287 c9dfb30)",
    "Mozilla/5.0 (X11; U; Linux; en-US) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.6",
    "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.2pre) Gecko/20070215 K-Ninja/2.1.1",
    "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9) Gecko/20080705 Firefox/3.0 Kapiko/3.0",
    "Mozilla/5.0 (X11; Linux i686; U;) Gecko/20070322 Kazehakase/0.4.5",
    "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.8) Gecko Fedora/1.9.0.8-1.fc10 Kazehakase/0.5.6",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_3) AppleWebKit/535.20 (KHTML, like Gecko) Chrome/19.0.1036.7 Safari/535.20",
    "Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; fr) Presto/2.9.168 Version/11.52",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.11 TaoBrowser/2.0 Safari/536.11",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.71 Safari/537.1 LBBROWSER",
    "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E; LBBROWSER)",
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; QQDownload 732; .NET4.0C; .NET4.0E; LBBROWSER)",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.84 Safari/535.11 LBBROWSER",
    "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)",
    "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E; QQBrowser/7.0.3698.400)",
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; QQDownload 732; .NET4.0C; .NET4.0E)",
    "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; SV1; QQDownload 732; .NET4.0C; .NET4.0E; 360SE)",
    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; QQDownload 732; .NET4.0C; .NET4.0E)",
    "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E)",
    "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.89 Safari/537.1",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.89 Safari/537.1",
    "Mozilla/5.0 (iPad; U; CPU OS 4_2_1 like Mac OS X; zh-cn) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8C148 Safari/6533.18.5",
    "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:2.0b13pre) Gecko/20110307 Firefox/4.0b13pre",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:16.0) Gecko/20100101 Firefox/16.0",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11",
    "Mozilla/5.0 (X11; U; Linux x86_64; zh-CN; rv:1.9.2.10) Gecko/20100922 Ubuntu/10.10 (maverick) Firefox/3.6.10",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
    ]
ua = UserAgent()
#若target中含有这些词，则把这些词提取出来作为relation
relation_list = ['有利于', '调整', '预防', '缓解', '治疗', '维持', '帮助', '保护', '延缓', '增强', '促进', '降低', '有益', '消除', '提高', '保护', '防治', '增进', '祛除', '驱除', '塑造', '收敛', '补充', '改善', '抑制']
#若target中含有这些词，则把这些词删去
delete_list = ['其他功效', '功效', '水平', '健康', '作用 ']
#将所有的target保存下来
overall_target_list = []
overall_complete_target_list = [] #用于存储完整的target
overall_triple_list = [] #用于存储所有的三元组
non_colon_num_list = [] #用于存储不含冒号的url在url_list中的index
#读取complete_target_list
fw_set = open("overall_complete_meishiChina_target_gongxiao", encoding='utf-8', mode='r')
overall_complete_meishiChina_target_gongxiao = json.load(fw_set)[1:-5]
fw_set.close()
# print(overall_complete_meishiChina_target_gongxiao)
# print(len(overall_complete_meishiChina_target_gongxiao))
# quit()
# fw_set = open("meishiChina_target_gongxiao_1500", encoding='utf-8', mode='r')
# f_1500 = json.load(fw_set)
# fw_set.close()
# fw_set = open("meishiChina_target_gongxiao_3143", encoding='utf-8', mode='r')
# f_3143 = json.load(fw_set)
# fw_set.close()
# f_5000 = f_1500 + f_3143
# target_5000 = sorted(f_5000, key=lambda i: len(i), reverse=True)[: -17]  #按照字符长度进行进行排序,过滤掉最后的空格，以及长度小于1的字符
# print(target_5000)
# quit()

def colon_process(sentence, source):
    '''
    处理含有冒号的一类“食用功效”，
    :param sentence:
    :return: 返回的是一句话中所有的三元组
    '''
    triple_list = []
    try:
        efficacy = re.findall(r'[0-9]{1,2}.(.+?)：', sentence)[0]
    except IndexError as e:
        return []
    target_list = re.split('、|，', efficacy)  # 若中间有顿号或者逗号，将其隔开
    # print(target_list)
    relation = ''
    # print(len(target_list))
    for target in target_list:
        triple = []
        overall_complete_target_list.append(target) #把删去relation之前的完整版本加入到list之中
        # 删去delete_list中的词
        for word in delete_list:
            if target.__contains__(word):
                target = target.replace(word, '')
        # 判断target中是否含有relation_trigger中的词
        for relation_trigger in relation_list:
            # print("target, relation_trigger:", target, relation_trigger)
            if target.__contains__(relation_trigger):  # 若含有relation_list中的词
                target = target.replace(relation_trigger, '')
                relation = relation_trigger
                # print("relation:", relation)
                break
        # print(relation)
        if not relation.strip():
            relation = '作用'
        # print("relation_last:", relation)
        triple.append(source)
        triple.append(relation)
        triple.append(target)
        triple_list.append(triple)
        overall_target_list.append(target) #将target添加进全局变量
    print(triple_list)
    return triple_list


def non_colon_process(sentence, source):
    '''
    处理不含有冒号的数据
    :param sentence:
    :param source:
    :return: 返回一个三元组list [[s,r,t]]
    '''
    triple_list = []
    relation = '作用'
    target_flag = 0
    for target in overall_complete_meishiChina_target_gongxiao: #收集sentence中含的所有的target, 这里应换成complete版的target_list
        triple = []
        if sentence.__contains__(target):
            target_flag = 1
            sentence = sentence.replace(target, '')
            #判断target中是否含有relation_words中的词
            for rw in relation_list:
                if target.__contains__(rw):
                    relation = rw
                    target = target.replace(rw, '')
                    break
            triple.append(source)
            triple.append(relation)
            triple.append(target)
            triple_list.append(triple)
    if not target_flag: #如果不包含有target，则直接返回空的list
        return []

    print(triple_list)
    return triple_list


def crawl_single_web(url, url_num):
    '''
    根据url对单个网页进行爬取
    :param url:
    :return:返回为一个list，list每个元素是个三元组 [[s,r,t]]
    '''

    # single_url = "https://www.meishichina.com/YuanLiao/AnChun/useful"
    single_url = url + "useful"
    # print(single_url)
    # headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0'}
    # USER_AGENT = random.choice(USER_AGENT_LIST)
    USER_AGENT = ua.random
    headers = {'user-agent': USER_AGENT}
    req = Request(
        url=single_url,
        headers=headers)
    try:
        time_out_flag = 1
        with eventlet.Timeout(10, False):#设置超时时间为10秒
            html = urlopen(req)
            time_out_flag = 0
        if time_out_flag: #若超时，则直接返回一个空的list
            print("10秒超时")
            return []
    except urllib.error.HTTPError:
        return []
    except UnicodeEncodeError as e:
        print(e)
        return []
    except urllib.error.URLError as e:
        print(single_url)
        print(e)
        return []
    bs = BeautifulSoup(html, "lxml")    #将html对象转化为BeautifulSoup对象
    source = bs.find('a', attrs={"href": url}).get('title')
    #---------------------------提取食用功效----------------------------------
    '''提取方法：
        先把文本提出来
        遇到“食用功效”，提取下面的内容，直到下面四字成语出现
    '''
    content = bs.find('div', attrs={"class": "category_usebox mt10 clear"}).getText()
    # print(content)
    # print(type(content))
    sentence_list = content.split('\n')
    efficacy_flag = 0
    for sentence in sentence_list:
        sentence = sentence.strip()
        if sentence == '食用功效':
            efficacy_flag = 1
        elif sentence == '适用人群':
            efficacy_flag = 0
        if efficacy_flag and not (sentence == '食用功效'):
            #提取sentence

            '''这里分为两种情况，1.标有数字：直接提取数字到冒号（正则表达式）。若含有“缓解”，“预防”这种词，把他们提出来当作relation。
            relation：预防 缓解 治疗 维持 帮助 保护 延缓 增强 促进 降低 有利于 消除 提高 保护 防治 增进 祛除 驱除 塑造 收敛 补充
            删除：作用 其他功效 功效 
            
             2.标有数字，但是没有冒号。只是用顿号将其隔开'''
            #有冒号
            if sentence.__contains__('：'):
                triple_list_1 = colon_process(sentence, source)
                if len(triple_list_1): #过滤掉空的三元组
                    overall_triple_list.extend(triple_list_1)
                # pass
            else: #无冒号
                '''方法一：把从带冒号中的内容进行匹配，匹配到了则直接算是target
                    写的时候应该搞两套target，一套是不去掉relation的target，另一套是去掉relation的target
                    使用 不去掉relation的target 来对不含冒号的sentence进行匹配，然后同样抽取其中的relation_words作为relation.记录没有冒号的那些list，并在下一轮直接使用。
                方法二：以“、，。 等 ”split，对于每个单元中2-4字的保留，其余的不要，并且两头的也不要。
                解决：方法一和方法二重复的问题'''
                non_colon_num_list.append(url_num) #记录没有冒号的id
                # print("sentence:", sentence)
                #若包含功效，则直接把功效提取出来。
                triple_list_2 = non_colon_process(sentence, source)
                if len(triple_list_2):
                    overall_triple_list.extend(triple_list_2)
                #否则进行split

if __name__ == '__main__':
    fw_set = open("meishiChina_url", encoding='utf-8', mode='r')
    url_list = json.load(fw_set)
    fw_set.close()
    print(len(url_list))
    for i in range(0, len(url_list)): #上次爬到2500  下次应该加 1.多线程 2.在一个程序中运行太长时间则跳过
        crawl_single_web(url_list[i], i)
        print(i)
        # print("overall_complete_target_list:", overall_complete_target_list)
        #每500个保存一回
        if i % 500 == 0 and not (i == 0):
            # fw_set = open("meishiChina_target_gongxiao", encoding='utf-8', mode='w')  # 存储source
            # json.dump(overall_complete_target_list, fw_set)
            # fw_set.close()
            # print("保存一次...")
            fw_set = open("overall_meishiChina_triple", encoding='utf-8', mode='w')  # 存储triple
            json.dump(overall_triple_list, fw_set)
            fw_set.close()
            print("保存triple...")
    print(overall_triple_list)

    # 将list存储为json
    fw_set = open("overall_meishiChina_triple", encoding='utf-8', mode='w')  # 存储triple
    json.dump(overall_triple_list, fw_set)
    fw_set.close()
    print("保存triple...")

    # fw_set = open("meishiChina_target_gongxiao", encoding='utf-8', mode='w')  # 存储source
    # json.dump(overall_complete_target_list, fw_set)
    # fw_set.close()
    # fw_set = open("meishiChina_triple_colon", encoding='utf-8', mode='w')  # 存储triple 带帽号的
    # json.dump(overall_triple_list, fw_set)
    # fw_set.close()
    # fw_set = open("non_colon_num_list", encoding='utf-8', mode='w')  # 存储没有冒号的id
    # json.dump(non_colon_num_list, fw_set)
    # fw_set.close()

    #把list从json中读取
    # fw_set = open("meishiChina_target_gongxiao", encoding='utf-8', mode='r')
    # f_json = json.load(fw_set)
    # fw_set.close()
    # print("读取：", f_json)