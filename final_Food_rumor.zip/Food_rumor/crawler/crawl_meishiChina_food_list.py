'''
2019.8.21
@author:Shuai Wang
爬取美食中国中的食物实体
'''

'''
步骤：
1.获取食物实体和url（已获取）
2.保存url和food_list、把实体添加进food list
3.根据url来获取食物的功能
    3.1 营养功效 --> 食用功效，其中会列出几点，可以用模板抽取
    3.2 把提取出功效加入target list
    3.3 提取target冒号后的一句话，从中可以选取target（功能和症状）
4. 爬取营养成分，分为两种：含有和不含有：热量、钾、钙、镁、碘等东西，然后再爬取这些营养成分的东西。
    4.1 好处：可以判断某种事物是否含有某种功能，例如，香蕉含钾，缺钾会导致抽筋，所以香蕉可以治疗抽筋。这点可以在论文里写。

5.目标：构建正样本
    正样本来源：
    5.1 美食天下饮食常识
        缺点：得先爬下来，然后手动选取短句话
    5.2 美食天下--> “食疗食谱”栏可以抽。 里面大多都是功能性的东西，可以用模板来抽
    5.3 美食天下--> 食材分类，把使用功效当作三元组。
        缺点：边单一，都是功能
'''

from urllib.request import urlopen#用于获取网页
from urllib.request import Request
import urllib3
from bs4 import BeautifulSoup#用于解析网页
import urllib
import json
import re
import chardet
import requests
import json

if __name__ == '__main__':
    http_url = "https://www.meishichina.com/yuanliao-search/"
    page = requests.get(http_url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0'})
    page.encoding = 'utf-8'
    print(page.apparent_encoding)
    soup = BeautifulSoup(page.text,  "html.parser")
    # print(soup)
    li = soup.find_all(name='a')

    food_list = []
    url_list = []
    for a in li:
        title = a.get('title')
        if title: #过滤掉None的
            food_list.append(title.strip())
            print(title)
        get_url = a.get('href')
        if len(get_url) > 10: #大于10的才是有效的url
            url_list.append(get_url)
            print(get_url)
    print(food_list)
    final_food_list = food_list[30:-11] #删去两端没用的部分
    final_url_list = url_list[30:-12]
    print(final_food_list)
    print(len(final_food_list))
    # print(li)
    #保存url和source
    #将list存储为json
    fw_set = open("meishiChina_food_list", encoding='utf-8', mode='w') #存储source
    json.dump(final_food_list, fw_set)
    fw_set.close()

    fw_set = open("meishiChina_url", encoding='utf-8', mode='w') #存储url
    json.dump(final_url_list, fw_set)
    fw_set.close()
    #把list从json中读取
    fw_set = open("meishiChina_food_list", encoding='utf-8', mode='r')
    f_json = json.load(fw_set)
    fw_set.close()
    print("读取：", f_json)

    fw_set = open("meishiChina_url", encoding='utf-8', mode='r')
    f_json = json.load(fw_set)
    fw_set.close()
    print("读取：", f_json)

    '''
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0'}
    # headers = {'Accept': '*/*',
    #            'Accept-Language': 'en-US,en;q=0.8',
    #            'Cache-Control': 'max-age=0',
    #            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.116 Safari/537.36',
    #            'Connection': 'keep-alive',
    #            'Referer': 'http://www.baidu.com/'
    #            }

    req = Request(
        url=http_url,
        headers=headers)
    
    html = urlopen(req)
    print(html.read())
    print(type(html.read()))
    print('ok')
    # content = html.read()
    # print(type(content))
    # print(content)

    # content.decode('')
    # seg_list = content.split('\n')
    # for seg in seg_list:
    #     print(seg)
        # print()

    # print(content)
    # print(content.decode('gbk'))
    # soup = BeautifulSoup(content)
    # print(soup.prettify())
    # print(html)
    bs = BeautifulSoup(html.text, "html.parser")  # 将html对象转化为BeautifulSoup对象
    print(bs)
    '''