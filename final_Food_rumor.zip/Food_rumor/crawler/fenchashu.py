a = ["a", 'b', 'c']
b = str(a)
c = list(b)
print(type(b))
print(type(c))
print(b)
print(c)
