import json
# 把list从json中读取
fw_set = open("overall_delete_relation_meishiChina_target_gongxiao", encoding='utf-8', mode='r')
f_json = json.load(fw_set)
fw_set.close()
print(len(f_json))
print("读取：", f_json)

fw_set = open("overall_complete_meishiChina_target_gongxiao", encoding='utf-8', mode='r')
f_json = json.load(fw_set)
fw_set.close()
print(len(f_json))
print("读取：", f_json)