import math
import numpy as np
a = np.array([1.1,2,3,4])
b = np.array([1,2,3,4])
c = a / 2
print(c)