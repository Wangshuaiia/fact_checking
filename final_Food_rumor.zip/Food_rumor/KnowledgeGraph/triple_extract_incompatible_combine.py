'''
date：2019.8.15
author Shuai Wang
code:从相克食物谣言中提取三元组
'''
import os
import jieba
jieba.load_userdict('userdict.txt')
import jieba.posseg as pseg   #用于词性标注
import json

'''
规则：
1.标志：只要出现这些标志，可以判定为食物相克类谣言
 + 同吃 一起吃 一起食用 同食 马上吃 马上喝 忌 相克 立即
2.模板 （这里只需要把两个食物提出来就行）
A忌B:直接提取 “忌” 前后的名词
A与B同食 :直接提取 “与” 前后的名词
A与B相克
A+B:直接提取 “+” 前后的名词
A*B 
'''
'''全局变量'''
#将所有的食物实体以list的形式保存下来
food_list = []

def judge_combine(line):
    '''
    判断该信息是否存在食物相克的标志
    :param line: 输入的一行文本
    :return: 0为不含有， 1为含有
    '''
    trigger_list = ['+', '同吃', '一起吃', '一起食用', '同食', '马上吃', '马上喝', '忌', '相克', '立即', '配', '同时吃', '再吃']
    for w in trigger_list:
        if line.__contains__(w):
            return 1
    return 0


def raw_text_process_line(line):
    '''
    处理一行原始数据，并返回
    :param line: 一行原始数据
    :return: 处理好的 两个相克的食物组成的三元组, 以一个list的形式返回
    '''
    # 分词
    if line.__contains__('忌'):
        seg_list = jieba.cut(line, cut_all=False, HMM=True)
        s = list(seg_list)
        try:  # 防止有的词把“忌”分不开
            j_index = s.index('忌')
            # print(s[j_index - 1], s[j_index + 1])
            food_list.append(s[j_index - 1])
            food_list.append(s[j_index + 1])
            # print([s[j_index - 1], '相克', s[j_index + 1]])
            return [s[j_index - 1], '相克', s[j_index + 1]]
        except ValueError:
            pass
    elif line.__contains__('与'):
        seg_list = jieba.cut(line, cut_all=False, HMM=True)
        s = list(seg_list)
        # print(s)
        try:  # 防止有的词把“与”分不开
            j_index = s.index('与')
            # print(s[j_index - 1], s[j_index + 1])
            food_list.append(s[j_index - 1])
            food_list.append(s[j_index + 1])
            # print([s[j_index - 1], '相克', s[j_index + 1]])
            return [s[j_index - 1], '相克', s[j_index + 1]]
        except ValueError:
            pass
    elif line.__contains__('*'):
        seg_list = jieba.cut(line, cut_all=False, HMM=True)
        s = list(seg_list)
        # print(s)
        try:  # 防止有的词把“*”分不开
            j_index = s.index('*')
            # print(s[j_index - 1], s[j_index + 1])
            food_list.append(s[j_index - 1])
            food_list.append(s[j_index + 1])
            # print([s[j_index - 1], '相克', s[j_index + 1]])
            return [s[j_index - 1], '相克', s[j_index + 1]]
        except ValueError:
            pass
    elif line.__contains__('+'):
        seg_list = jieba.cut(line, cut_all=False, HMM=True)
        s = list(seg_list)
        # print(s)
        try:  # 防止有的词把“*”分不开
            j_index = s.index('+')
            # print(s[j_index - 1], s[j_index + 1])
            food_list.append(s[j_index - 1])
            food_list.append(s[j_index + 1])
            # print([s[j_index - 1], '相克', s[j_index + 1]])
            return [s[j_index - 1], '相克', s[j_index + 1]]
        except ValueError:
            pass


def combine_raw_text_process(raw_text_lines):
    '''
    处理原始数据，分词，标词性
    :param raw_text_lines:是一个list
    :return:以一个list的形式返回三元组,每个三元组又是个list
    '''
    triple_list = []
    count = 0
    for one_line in raw_text_lines:
        line = one_line.strip()
        trip = raw_text_process_line(line)
        if trip:
            count += 1
            print(count, "trip:", trip)
            triple_list.append(trip)
    return triple_list
        #将三元组保存下来写到文件中  或者 返回三元组

            # words = pseg.cut(line)
            # for w in words:
            #     print(w, w.flag)
            # print(seg_list[2].flag)


if __name__ == '__main__':
    #读取相克文件中的所有谣言子文件
    path = 'D:\\Dataset\\rumors\\food_Rumor\\false_message\\mutual restriction'
    files = os.listdir(path)
    # print(files)
    test_num  = 0
    overall_mutual_restrict_triple = []
    for file_name in files:
        print(file_name,'--------------------------')
        test_num += 1
        file_path = path + "\\" + file_name
        with open(file_path, encoding='utf-8', mode='r') as f:
            raw_text = f.readlines()
            print(raw_text)
            overall_mutual_restrict_triple = overall_mutual_restrict_triple + combine_raw_text_process(raw_text)
        # if test_num == 5:
        #     quit()
    print(len(overall_mutual_restrict_triple))
    print("overall_mutual_restrict_triple:", overall_mutual_restrict_triple)
    print(len(food_list))
    print(food_list)

    #将这几个文件夹中全部含有相克的三元组 overall_mutual_restrict_triple存储为json
    fw_set = open("overall_mutual_restrict_triple", encoding='utf-8', mode='w')
    json.dump(overall_mutual_restrict_triple, fw_set)
    fw_set.close()

    #将list存储为json
    fw_set = open("incompatible_food_list", encoding='utf-8', mode='w')
    json.dump(food_list, fw_set)
    fw_set.close()

