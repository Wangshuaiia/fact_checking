'''
2019.8.16
使用模板从短句子中提取三元组
@author: Shuai Wang
'''
import jieba
import jieba.posseg as pseg   #用于词性标注
from triple_extract_incompatible_combine import judge_combine
from triple_extract_incompatible_combine import raw_text_process_line
import sys
import json
# import torch


'''
思路：
使用jieba,对词性进行标注，以动词为中心进行标注
有一些标志性词需要挑出来：
边：
    可以 有益 能 治 有助于 有助 助 补 会
    含有 含
    是 ：提取前后的名词
    引发 导致 诱发 
    放了 放 使用了 使用：用的时候按 放 和 使用 来处理，因为‘了’会分开
target：
致癌
细节处理：
吃 喝 常吃 常喝 在前面的时候，直接删掉，只要前两个词包含“吃、喝”，就把他们删掉
'''

#检验是否含有中文字符
def is_contains_chinese(strs):
    for _char in strs:
        if '\u4e00' <= _char <= '\u9fa5':
            return True
    return False

'''
全局变量
'''
trigger_list = ['可以', '有益', '能', '治', '助', '补', '会', '含', '引发', '致', '诱发', '放', '使用', '缓解', '造成'] #规则触发词
relation_words = ['是', '长', '中的', '带', '因为', '优于']
# 读取所有的食物实体
'''
# 把list从json中读取
fw_set = open("../crawler/food_list_set", encoding='utf-8', mode='r')
f_web = json.load(fw_set)
fw_set.close()
print(len(f_web))
print(f_web)

fw_set = open("incompatible_food_list", encoding='utf-8', mode='r')
f_mutual = json.load(fw_set)
fw_set.close()
print(len(f_mutual))
print(f_mutual)
all_food_list = f_web + f_mutual
print(len(all_food_list))
print(len(set(all_food_list)))

all_food_set_list = list(set(all_food_list))
for food in all_food_set_list:  #迭代过程中不能对其进行变化
    if (not is_contains_chinese(food)) or (len(food) > 6):
        all_food_list.remove(food)
        print("food:", food)

all_food_set_list = list(set(all_food_list))
print(len(all_food_set_list))
print(all_food_set_list)

# 讲list存储为json
fw_set = open("all_food_list_set", encoding='utf-8', mode='w')
json.dump(all_food_set_list, fw_set)
fw_set.close()
'''

# 把list从json中读取
#将food entity 从文件中读取

# 读取所有的食物实体,source list
fw_set = open("all_food_list_set", encoding='utf-8', mode='r')
f_food_list = json.load(fw_set)
fw_set.close()
#在此临时修改一些词
f_food_list.remove('酸')
f_food_list.remove('双孢蘑菇')
f_food_list.remove('会')
f_food_list.remove('牛')
f_food_list.remove('煮')
f_food_middle_ = f_food_list + ['盐', '食盐', '蘑菇', '糖', '茶', '消炎药', '可乐', '小龙虾', '药', '牛排', '榴莲', '转基因'] #手动添加一些词
#按照字符从长到短的顺序排列开
f_food_list = sorted(f_food_middle_, key=lambda i:len(i), reverse=True)
print(len(f_food_list))
print(f_food_list)

overall_triple_list = [] #全局变量，用于存储三元组

#在这里得到了t_list, target所需要的内容
with open("target_list.txt",encoding='utf-8', mode='r') as f:
    #把target list 的汉字个数从大往小排，把大的放前面
    t_list = (f.readlines())[0].split(' ')
    target_list_middle_variable = list(set(t_list))
    target_list_middle_variable.remove('')
    t_list = sorted(target_list_middle_variable, key=lambda i:len(i), reverse=True)


def judge_contains_food_entity(line):
    '''
    判断句子中是否含有食物实体
    :param line:
    :return: flag，所有含有的实体
    '''
    flag = 0
    word_list = []
    for w in f_food_list:
        if line.__contains__(w):
            word_list.append(w)
            flag = 1
    return flag, word_list


def judge_contains_target(line):
    '''
    判断句子中是否含有target
    :param line:
    :return: flag，所含有的target
    '''
    flag = 0
    target = ''
    for w in t_list: #遇到第一个就立马break返回
        if line.__contains__(w):
            flag = 1
            target = w
            break
    return flag, target


def food_entity_process(line, entity_list):
    '''
    对含有食物实体的句子进行处理，这里只对非食物相克类的line进行处理
    模板：食物都放在s的位置上，动词之后再匹配，最后放功效
    t部分，应该加一些词，例如：致癌
    为解决问题的例子：
    源claim：可乐腐蚀性很强，能溶解一条鱼
    提取后：腐蚀性 能 溶解鱼
    :param line:
    :param entity_list:包含所含有实体的list, 筛选出第一个食物实体作为s
    :return:
    '''
    '''含有食物实体(source)之后，还需分为以下几类：
    1.有target
        1.1 relation，relation是触发词，claim中含有触发词
        1.2 抽取剩余的动词当relation
        1.3 除了relation和target没有其他词了，添加“作用”当target
    2.无target
        2.1 名词当target 动词做 relation (未做， 如 121、122) 
    
    其他还可以分为以下几类：
    1.不含食物实体（source），但含有target。(未做)
        1.1 把target中含有的内容直接单做target，第一个名词作为source，若有trigger则抽trigger作为relation，若无trigger则抽取动词作为relation，若无动词则填“作用”
    2.既不含有食物实体，又不含有target。（已做）
        2.1 使用parser（未做）
        2.2 重新编写模板匹配
    '''
    #--------------------------确定source-----------------------------------
    # 判断两个实体的位置先后
    index_dict = {}  # 建立一个存储index的词典
    for entity in entity_list:
        index_dict[line.find(entity)] = entity
    # 对字典按照value进行排序
    index_list = sorted(index_dict.keys())
    source = index_dict[index_list[0]] #筛选出第一个食物实体作为s
    '''
    筛选出source之后如何进行处理？
    处理方式1：也利用相似的手段构建target数据集，然后就有了source和target
    target 重点词汇：重金属 致癌 癌 病 减肥 脏 炎症 脑炎 毒素 毒 砒霜 等等，见target_list.txt
    处理方式2：
    先把source放在第一个
    若包含target接着提取target
    选择动词作为relation
    源claim：大蒜炝锅致癌 提取后：锅 致 
    对relation进行抽取，常用词：超标 多 
    '''
    # --------------------------确定target-----------------------------------
    target = ''
    contain_s_r_flag = 0 #标记source 和 target 都包含在词典之中
    if judge_contains_target(line)[0]: #含有target
        target = judge_contains_target(line)[1]
        contain_s_r_flag = 1
    else: #不含有target
        #把除了trigger外的名词的最后一个当target，如果没有另外一个名词，则直接忽略这条claim
        sentence = line.replace(source, '')
        seg_list = pseg.cut(sentence)
        list_middle_no_use = []
        for w in seg_list:
            if w.flag.__contains__('n'):
                list_middle_no_use.append(w.word)
        if len(list_middle_no_use):
            target = list_middle_no_use[len(list_middle_no_use)-1]
        else: #如果没有其他名词，则忽略该条claim，直接返回空的list
            return []
    '''
    把source和target填好后，先判断有没有trigger，若有，则把trigger填上去。若没有，则把动词抽取出来，若无动词，则抽取其形容词。
    '''
    # --------------------------确定relation-----------------------------------
    relation = ''
    if judge_contains_all_trigger(line)[0]:
        # flag, relation = judge_contains_trigger(line)
        all_list_middle_no_use_1 = trigger_list + relation_words  #在这里直接把trigger作为relation填上去
        print("line:", line)
        for w in all_list_middle_no_use_1:
            if line.__contains__(w):
                relation = w
                break

    #直接找一个动词作relation填上去即可
    #去掉原来的target和source的词，对剩下的词进行词性分析
    else:
        #若含有动词，则把动词提出来作为relation
        sentence = line #把line赋给另一个变量，防止line在中间被改变
        #这里需要改，需要把两个list合并为一个, 然后按照字符串长度按顺序进行排序
        all_list_middle_no_use = f_food_list + t_list
        all_list = sorted(all_list_middle_no_use, key=lambda i:len(i), reverse=True)
        for w in all_list:
            if sentence.__contains__(w):
                sentence = sentence.replace(w, '')

        #把其中的动词提取出来，当relation
        # 对剩下的sentence进行词性分解，找出动词作为relation
        if sentence.strip():
            seg_list = list(pseg.cut(sentence))
            print("seg_list:", seg_list)
            for w in seg_list:
                if w.flag.__contains__('v'):
                    relation = w.word
                    print("relation: ", w)
                    break
            if not relation.strip():
                if contain_s_r_flag: #若source和target都在字典当中，则不管relation含不含动词，都要保留这个三元组
                    relation = '作用'
                else: #若中间没有动词，并且不是s和t都在list中,忽略该claim
                    return []
        else:
            relation = '作用'  # 若为空，再用“作用”代替

    '''这里的缺点，还有的三元组是三缺二'''
    triple_middle_no_use = []
    triple_middle_no_use.append(source)
    triple_middle_no_use.append(relation)
    triple_middle_no_use.append(target)
    print("triple_middle_no_use:", triple_middle_no_use)
    return triple_middle_no_use



def additional_handling(line):
    '''
    把漏网的食物相克的句子，例如“杨梅海鲜不能同吃”，处理。方法：直接把多个食物实体提取出来，第一个与后面的冲突
    :param line:
    :return: 返回的是一个list,每个list的元素是相克三元组 [[s,r,t]]
    '''

    triple_list = []
    flag, entity_list = judge_contains_food_entity(line)
    if flag:
        #判断两个实体的位置先后
        index_dict = {} #建立一个存储index的词典
        for entity in entity_list:
            # index_dict[entity] =
            index_dict[line.find(entity)] = entity
        #对字典按照value进行排序
        index_list = sorted(index_dict.keys())
        #若是只有两个食物实体
        if len(index_list) == 2:
            triple = []
            triple.append(index_dict[index_list[0]])
            triple.append('相克')
            triple.append(index_dict[index_list[1]])
            triple_list.append(triple)
        # 若是有多个食物实体
        elif len(index_list) > 2:
            source = index_dict[index_list[0]]
            for i in range(1,len(index_list)):
                triple = []
                triple.append(source)
                triple.append('相克')
                triple.append(index_dict[index_list[i]])
                triple_list.append(triple)
        elif len(index_list) < 2:  #如果里面少于两个，则走模板
            triple_list.append(raw_text_process_line(line))
    return triple_list

def judge_contains_all_trigger(line):
    '''
    判断是否含有触发词和标志性词，这种情况只在food_entity_process() 中使用
    与judge_contains_trigger的区别是，多加入了relation_lists中的词
    :param line:
    :return: flag
    '''
    flag = 0
    all_trigger_list = trigger_list + relation_words
    for w in all_trigger_list:
        if line.__contains__(w):
            flag = 1
            return flag, w
    return flag, ''


def judge_contains_trigger(line):
    '''
    判断是否含有触发词
    :param line:
    :return:flag 是否含有触发词
    '''
    flag = 0
    for w in trigger_list:
        if line.__contains__(w):
            flag = 1
            return flag, w
    return flag, ''


def trigger_process(line, word):
    '''
    对含有标志词的句子进行处理
    n + trigger + v、n 即提取trigger之前的名词和trigger之后的动词名词
    :param line:
    :return:
    '''
    #删去“吃、喝”
    line = line.replace('吃', '')
    line = line.replace('喝', '')

    x = line.split(word)
    pro_list = list(pseg.cut(x[0]))
    # print(pro_list)
    source = ''
    for w in pro_list:#抽取前半部分的最后一个名词
        if w.flag.__contains__('n'):
            source = w.word
            # print("source:", source)
    de_list = list(pseg.cut(x[1]))
    # print(de_list)
    target_v = ''
    target_n = ''
    for w in de_list:#抽取后半部分的动词加名词
        if w.flag.__contains__('v'):
            target_v = w.word
        elif w.flag.__contains__('n'):
            target_n = w.word
    # print("target_v, target_n:", target_v, target_n)
    target = str(target_v) + str(target_n)
    #三元组打印
    triple = []
    if source.strip() and target.strip(): #保证这两个都是非空的情况下才返回
        triple.append(source)
        triple.append(word)
        triple.append(target)
        # print(source, word, target)
        return triple
    else: #只要又一个是空的就返回空
        return []


def no_target_source_process(line):
    '''
    没有target和source的情况，在此情况对数据进行处理
    :param line:
    :return: 返回的是三元组target, 若不符合条件，则返回的是一个空的list
    '''
    seg_list = list(pseg.cut(line))
    print("other类： ", seg_list)
    # 把第一个名词放在第一个， 动词放中间，最后一个名词放在最后一个
    n_list = []
    v_list = []
    for w in seg_list:
        if w.flag.__contains__('n'):
            n_list.append(w.word)
        elif w.flag.__contains__('v'):
            v_list.append(w.word)
    triple = []
    if len(n_list) > 1:  # 若有大于等于2个名词
        source = n_list[0]
        target = n_list[len(n_list) - 1]
        # 若包含trigger，则trigger为relation
        relation = ''
        trigger_list_middle_no_use = trigger_list + relation_words
        for w in trigger_list_middle_no_use:
            if line.__contains__(w):
                relation = w
                break
        # 若不包含trigger，则选一个动词为relation
        if not relation.strip():#若relation为空，则标志着line中不包含trigger中的词
            if len(v_list): #若含有动词，则选动词
                relation = v_list[0]
            else: # 若无动词，则填“作用”
                relation = '作用'
        triple.append(source)
        triple.append(relation)
        triple.append(target)
    elif len(n_list) == 1:  # 若只有一个名词
        pass  # 此种情况不要了
        # source = n_list[0]
        # relation = ''
        # target = ''
        # for w in seg_list:
        #     if w.flag.__contains__('v') or w.flag.__contains__('a'):
        #         target = w.word
        #         relation =
        #         break
        #
        # target = 长动词 或者形容词 或者 i
        # relation = 短动词
    elif len(n_list) == 0:  # 若一个名词都没有，直接将这条claim丢掉不要
        pass
    # print(triple)
    return triple


def template_process(text_lines):
    '''
    在这个函数中，针对不同的claim来分配不同的模板
    :param text_lines:
    :return:
    '''
    '''在自己构建模板的时候可以考虑抛弃一些谣言，收集80%以上的够用就可以了'''
    count = 0
    for raw_line in text_lines:
        line = raw_line.strip()
        count += 1
        # print(str(count) + '--------------------------')
        # print(line)
        '''模板一：食物相克模板'''
        #判断有没有食物相克的出发词，若有，则走食物相克规则
        if judge_combine(line):
            # trip = raw_text_process_line(line)  #返回的是list形式的三元组
            # #有些含有食物相克标志性词的需要额外处理
            # if not trip:
            trip_return_list = additional_handling(line)
            for trip in trip_return_list: #这里的trip是三元组
                print(trip)
                overall_triple_list.append(trip)

        #从这里开始，模板需要做改变
        # elif judge_contains_food_entity(line)[0] or judge_contains_target(line)[0]: #这里需要做出改变，只含有target的词应该再弄一个模板
        elif judge_contains_food_entity(line)[0]:
            print("--含有食物实体--")
            entity_list = judge_contains_food_entity(line)[1]
            trip = food_entity_process(line, entity_list) #返回三元组，但有可能返回是空的
            if len(trip) == 3: #过滤掉空的
                overall_triple_list.append(trip)
        elif judge_contains_target(line)[0]:
            '''不含有食物实体，但包含target实体  （未做）'''
            pass
        elif judge_contains_trigger(line)[0]:
            '''模板二：包含触发词的模板
            如果返回的triple中三缺二，则换一套模板
            '''
            print("trigger类")
            # 删去“吃、喝”
            line = line.replace('吃', '')
            line = line.replace('喝', '')
            #判断有没有包含上面的触发词，若有触发词，则走的是另一套规则
            flag, word = judge_contains_trigger(line)
            if flag:
                # print(words)
                trip = trigger_process(line, word)
                if len(trip) == 3: #过滤掉空的三元组
                    overall_triple_list.append(trip)
            #含有触发词，指定触发词的几个模板
            '''模板三：包含食物实体模板
            食物实体来源：1.从网上爬取的六百多个实体 
            2.食物相克中的食物
            最后用set存储这些实体
            '''
        else: #这属于啥都没有的一类，不包含 s, r, t 中的任何一个
            trip = no_target_source_process(line)
            if len(trip) == 3:
                overall_triple_list.append(trip)
            #不满足这些条件的其他claim也丢掉


if __name__ == '__main__':
    '''
    可改善之处：增大entity的量
    '''
    path = "D:\\Dataset\\rumors\\food_Rumor\\false_message\\china_food_rumor_refuting.txt"
    with open(path, encoding='utf-8', mode='r') as f:
        text_lines = f.readlines()
        template_process(text_lines)
    print(len(overall_triple_list))
    print(overall_triple_list)
    for triple in overall_triple_list:
        print(triple)

    print(len(overall_triple_list))
    #将政府辟谣网站中所有的triple 存储为json
    fw_set = open("overall_ZhengFuRumor_triple", encoding='utf-8', mode='w')
    json.dump(overall_triple_list, fw_set)
    fw_set.close()

    #-----------------------在以下过程中，将相克的三元组和政府辟谣中的三元组合并到一起---------------------------------
    fw_set = open("overall_mutual_restrict_triple", encoding='utf-8', mode='r')
    f_json = json.load(fw_set)
    fw_set.close()
    print(len(f_json))
    print("读取：", f_json)

    overall_negative_triple = f_json + overall_triple_list
    fw_set = open("overall_negative_triple", encoding='utf-8', mode='w') #存储所有的谣言三元组，包括食物相克和政府辟谣网站上面的
    json.dump(overall_negative_triple, fw_set)
    fw_set.close()
    print(len(overall_negative_triple))

