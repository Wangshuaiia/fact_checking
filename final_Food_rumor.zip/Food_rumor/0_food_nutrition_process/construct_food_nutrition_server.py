'''
Date:2019.10.23
Code: construct_food_nutrition.py的服务器版
'''
import numpy as np
import json


def retrieve(entity_in, nutrition_dict):
    key_list = nutrition_dict.keys()
    full_word_contain_list = []
    for key in key_list:
        if entity_in in key:
            full_word_contain_list.append(key)

    if not len(full_word_contain_list) == 0:
        return full_word_contain_list

    last_word_list = ['菇','豆','稻','米','肉','骨', '菜','鸡','花','椰','菌','蕉','肝','心', '肺', '蛋', '乳','粉','奶','糖','鱼','虾','蟹','瓜','油','酒','曲','酿']

    if entity_in[-1] in last_word_list:
        match_last_word_list = []
        for key in key_list:
            if entity_in[-1] == key[-1]:
                match_last_word_list.append(key)
        return match_last_word_list

    if len(entity_in) == 2:
        match_last_word_list = []
        match_first_word_list = []
        for key in key_list:
            if entity_in[-1] in key:
                match_last_word_list.append(key)
            elif entity_in[0] in key:
                match_first_word_list.append(key)
        if not len(match_last_word_list) == 0:
            return match_last_word_list
        elif not len(match_first_word_list) == 0:
            return match_first_word_list
        else:
            return None

    elif len(entity_in) == 3:
        match_last_two = []
        match_last_one = []
        match_first_two = []
        match_first_one = []
        for key in key_list:
            if entity_in[-2:] in key:
                match_last_two.append(key)
            elif entity_in[-1] in key:
                match_last_one.append(key)
            elif entity_in[:2] in key:
                match_first_two.append(key)
            elif entity_in[0] == key[0]:
                match_first_one.append(key)
        if not len(match_last_two) == 0:
            return match_last_two
        elif not len(match_last_one) == 0:
            return match_last_one
        elif not len(match_first_two) == 0:
            return match_first_two
        elif not len(match_first_one) == 0:
            return match_first_one
        else:
            return None
    elif len(entity_in) > 3:
        match_last_two = []
        match_first_two = []
        for key in key_list:
            if entity_in[-2:] in key:
                match_last_two.append(key)
            elif entity_in[:2] in key:
                match_first_two.append(key)
        if not len(match_first_two) == 0:
            return match_first_two
        elif not len(match_last_two) == 0:
            return match_last_two
        else:
            return None


def judge_full_match(entity_in, nutrition_dict):
    if entity_in in nutrition_dict.keys():
        return True
    else:
        return False


def get_nutrition(entity_in, nutrition_dict):
    flag = judge_full_match(entity_in, nutrition_dict)
    if flag:
        return nutrition_dict[entity_in]
    else:

        food_key_list = retrieve(entity_in, nutrition_dict)
        print(food_key_list)
        if food_key_list:
            average = np.zeros(len(nutrition_dict[food_key_list[0]]), dtype=np.float64)
            for key in food_key_list:
                average += np.array(nutrition_dict[key])

            average = average / len(food_key_list)
            return average
        else:
            return np.zeros(len(nutrition_dict[food_key_list[0]]), dtype=np.float64)


def construct_nutrition_content(input_list):
    input_list = [[0, 7, 14], [30, 1, 2], [34, 2, 2]]

    with open("../0_food_nutrition_process//nutrition_dict", encoding='utf-8', mode='r') as fr:
        # json.dump(nutrition_dict, fw)
        nutrition_dict = json.load(fr)
    with open("../0_food_nutrition_process//id2entity_dict", encoding='utf-8', mode='r') as fr:
        # json.dump(id2entity_dict, fw)
        id2entity_dict = json.load(fr)
    print(nutrition_dict)
    print(id2entity_dict)

    return_nutrition_vector_list = []
    for triple_ in input_list:
        head_id = str(triple_[0])
        entity_str = id2entity_dict[head_id]
        vector = get_nutrition(entity_str, nutrition_dict)
        return_nutrition_vector_list.append(vector)
    return return_nutrition_vector_list


if __name__ == '__main__':
    test_list = []
    res_list = construct_nutrition_content(test_list)
    print(res_list)

