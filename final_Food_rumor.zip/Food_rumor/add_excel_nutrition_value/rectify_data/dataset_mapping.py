'''
对训练集、验证集 和 测试集中所有的谣言数据进行mapping，来防止谣言中的食物在知识图谱中没有的现象
@Date:2019.12.9
@author: Shuai Wang
'''
import json
# 读取mapping字典
# with open("../extract_head_and_tail_neighbor/id_entity_rumor_food_mapping", encoding='utf-8', mode='r') as f:
#     id_entity_rumor_food_mapping = json.load(f)
# print(id_entity_rumor_food_mapping)  # 需要重新构造
# # quit()
# def convert(list_in):
#     list_out = []
#     for triple_ in list_in:
#         head = triple_[0]
#         tail = triple_[1]
#         relation = triple_[2]
#         triple_new = []
#
#         if head in id_entity_rumor_food_mapping.keys():
#             triple_new.append(id_entity_rumor_food_mapping[head])
#         else:
#             triple_new.append(head)
#
#         if tail in id_entity_rumor_food_mapping.keys():
#             triple_new.append(id_entity_rumor_food_mapping[tail])
#         else:
#             triple_new.append(tail)
#         triple_new.append(relation)
#         list_out.append(triple_new)
#     return list_out
#
#
# # ------------------读取训练集并写入新的训练集-----------------------
# with open("../construct_negative_triple/train_construct_negative_triple", encoding='utf-8', mode='r') as f:  # 5373
#     train_neg_list = json.load(f)
#     # print(train_neg_list)
#     # print(len(train_neg_list))
#     new_train_negative_list = convert(train_neg_list)
#     # print(new_train_negative_list)
#     # print(len(new_train_negative_list))
# with open("train_construct_negative_triple", encoding='utf-8', mode='w') as fw:  # 存储mapping后的数据
#     json.dump(new_train_negative_list, fw)
#
# # -------------------读取验证集并写入新的验证集------------------------
# with open("../construct_negative_triple/valid_construct_negative_triple", encoding='utf-8', mode='r') as f:  # 1000
#     valid_neg_list = json.load(f)
#     # print(valid_neg_list)
#     new_valid_negative_list = convert(valid_neg_list)
#     # print(new_valid_negative_list)
# with open("valid_construct_negative_triple", encoding='utf-8', mode='w') as fw:  # 存储mapping后的数据
#     json.dump(new_valid_negative_list, fw)
# # --------------------读取测试集并写入新的测试集------------------------
# with open("../construct_negative_triple/negative_rumor_test2id.txt", encoding='utf-8', mode='r') as f:  # 96
#     test_neg_list_read_from_file = f.readlines()
# test_neg_list = []
# for line in test_neg_list_read_from_file:
#     words = line.split()
#     try:
#         triple_middle = []
#         triple_middle.append(words[0])
#         triple_middle.append(words[1])
#         triple_middle.append(words[2])
#         test_neg_list.append(triple_middle)
#     except IndexError:
#         pass
# # print(test_neg_list)
# new_test_negative_list = convert(test_neg_list)
# # print(new_test_negative_list)
# with open("negative_rumor_test2id.txt", encoding='utf-8', mode='w') as fw:  # 存储mapping后的数据
#     json.dump(new_test_negative_list, fw)

# ---------------构造可解释性验证的数据集---------------------
# ---------正样本500条，不需要对其内容进行mapping----------
with open("../process_to_OpenKE_format/valid2id.txt", encoding='utf-8', mode='r') as f:  # 从这992个样本中选取500个作为正样本
    valid_pos_list_read_from_file = f.readlines()
    print(len(valid_pos_list_read_from_file))
    # print("读取：", valid_pos_list_read_from_file)
    valid_pos_list = []
    for line in valid_pos_list_read_from_file:
        words = line.split()
        try:
            triple_middle = []
            triple_middle.append(words[0])
            triple_middle.append(words[1])
            triple_middle.append(words[2])
            valid_pos_list.append(triple_middle)
        except IndexError:
            pass
explainable_verification_positive = valid_pos_list[:749]
with open("../extract_head_and_tail_neighbor/explainable_verification_positive", encoding='utf-8', mode='w') as fw:
    json.dump(explainable_verification_positive, fw)

# --------------负样本500条，选取delete_list之外的所有负样本------------------
'''负样本在extract_neighbor中构造，名字为explainable_verification_negative'''
