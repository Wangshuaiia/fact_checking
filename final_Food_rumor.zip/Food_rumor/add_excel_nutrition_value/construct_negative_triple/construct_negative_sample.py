'''
添加入excel文件，构造负样本，供给训练直接使用
@author：Shuai Wang
Date: 2019.12.7
'''
import json
import random
import collections
'''全局变量'''

entity2id_dict = dict()
relation2id_dict = dict()
source_relation_dict = dict() #这个词典用于存储source和哪些relation相连接

train_triple_list = []  # 这个用于存储美食天下中用于训练的 triple
# 读取字典
with open("../process_to_OpenKE_format//entity2id.txt", encoding='utf-8', mode='r') as f:
    fl = f.readlines()

    for line in fl:
        words = line.split()
        try:
            # print(words[1])
            # print(words[0])
            entity2id_dict[words[0]] = words[1]
        except IndexError:
            pass
with open("../process_to_OpenKE_format//relation2id.txt", encoding='utf-8', mode='r') as f:
    fl = f.readlines()
    for line in fl:
        words = line.split()
        try:
            relation2id_dict[words[0]] = words[1]
        except IndexError:
            pass

with open("../process_to_OpenKE_format/train2id.txt") as f:
    fl = f.readlines()
    for triple_ in fl:
        words = triple_.split()
        try:
            # print(words[0], words[1], words[2])
            list_middle = []
            list_middle.append(words[0])
            list_middle.append(words[1])
            list_middle.append(words[2])
            train_triple_list.append(list_middle)
            if words[0] in source_relation_dict.keys():
                list_middle2 = []
                list_middle2.extend(source_relation_dict[words[0]])
                list_middle2.append(words[2]) #添加relation
                source_relation_dict[words[0]] = list_middle2
            else:
                list_middle3 = []
                list_middle3.append(words[2])
                source_relation_dict[words[0]] = list_middle3
        except IndexError:
            pass

meat_and_aquatic_id = [] #source
with open("../construct_negative_triple/肉禽类and水产类.txt", encoding='utf-8', mode='r') as f:
    fl = f.readlines()
    for entity in fl:
        try:
            idd = entity2id_dict[entity.strip()]
            meat_and_aquatic_id.append(idd)
            # meat_and_aquatic_list.extend(find_id_set(idd))
        except KeyError:
            # print("entity:", entity)
            pass

fruit_and_vegetable_id = [] #source
with open("../construct_negative_triple/水果类and蔬菜类.txt", encoding='utf-8', mode='r') as f:
    fl = f.readlines()
    for entity in fl:
        try:
            idd = entity2id_dict[entity.strip()]
            fruit_and_vegetable_id.append(idd)
            # fruit_and_vegetable_list.extend(find_id_set(idd))
        except KeyError:
            # print("entity:", entity)
            pass

#1.从谣言样本中构造
def sample_from_rumor():
    '''
    从谣言样本中构造负样本，构造其中的三元组。
    :return:
    '''
    #读取所有的谣言三元组
    negative_rumor = []
    with open("negative_rumor_train2id.txt", encoding='utf-8', mode='r') as f:
        fl = f.readlines()
        for triple_ in fl:
            words = triple_.split()
            triple_middle =[]
            triple_middle.append(words[0])
            triple_middle.append(words[1])
            triple_middle.append(words[2])
            negative_rumor.append(triple_middle)
            # print("triple_.strip():", triple_.strip())
        print(negative_rumor)
        print(len(negative_rumor))
    return negative_rumor

def find_id_set(id_list):
    '''
    根据id来寻找对应的 target set
    :return: target list
    '''
    target_list = []
    for triple_ in train_triple_list:
        if triple_[0] in id_list:
            target_list.append(triple_[1])
    # print("target_list", target_list)
    # print("len(target_list):", len(target_list))
    return target_list

# 1.%查看这里是否能够多生成一些三元组，不用使用营养来构造负向三元组%
# 2.%利用营养构造负向三元组，把无营养，改为营养，即是负向三元组%

# 2.构造不同种类之间匹配的谣言，例如：水产和奶制品，水产和水果
def construct_from_different_class():
    '''
    从不同的食品种类中构造谣言，并不是随机采样
    :return:
    '''
    # 读取水果类and蔬菜类食物，转为id,通过id来找对应的set
    fruit_and_vegetable_target_list = find_id_set(fruit_and_vegetable_id)  # target
    # 读取肉禽类and水产类食物，转为id,通过id来找对应的set
    meat_and_aquatic_target_list = find_id_set(meat_and_aquatic_id)  # target

    #-----------去除两个集合中的交集，构建错误三元组----（top）----------
    fruit_and_vegetable_list_delete = []  # 去除交集后的list
    for target in fruit_and_vegetable_target_list:
        if target in meat_and_aquatic_target_list:
            pass
        else:
            fruit_and_vegetable_list_delete.append(target)

    meat_and_aquatic_list_delete = []
    for target in meat_and_aquatic_target_list:
        if target in fruit_and_vegetable_target_list:
            pass
        else:
            meat_and_aquatic_list_delete.append(target)
    # -----------去除两个集合中的交集，构建错误三元组----（bottom）----------
    # print("len(fruit_and_vegetable_list_delete):", len(fruit_and_vegetable_list_delete))  # 1018
    # print("len(meat_and_aquatic_list_delete):", len(meat_and_aquatic_list_delete))  # 480
    negative_triple = []  # 用于存储的生成虚假三元组的triple
    for source in fruit_and_vegetable_id:
        for i in range(25):  # 每个id生成40个负面例子
            try:
                relation = random.choice(source_relation_dict[source])
                target = random.choice(meat_and_aquatic_list_delete)
            except KeyError:
                # print("quit:", source)
                break
            triple_middle = []
            triple_middle.append(source)
            triple_middle.append(target)
            triple_middle.append(relation)
            if triple_middle not in train_triple_list:
                negative_triple.append(triple_middle)

    for source in meat_and_aquatic_id:
        for i in range(18):
            try:
                relation = random.choice(source_relation_dict[source])
                target = random.choice(fruit_and_vegetable_list_delete)
                triple_middle = []
                triple_middle.append(source)
                triple_middle.append(target)
                triple_middle.append(relation)
                if triple_middle not in train_triple_list:
                    negative_triple.append(triple_middle)
            except KeyError:
                # print("2 quit:", source)
                break

    print(negative_triple)
    print("len(negative_triple):", len(negative_triple))
    return negative_triple

# 3.谣言中出现频率高的target(词)，例如：致癌等
def construct_by_frequency():
    fw_set = open("../../KnowledgeGraph/overall_negative_triple", encoding='utf-8', mode='r')
    negative_list = json.load(fw_set)

    fw_set.close()
    target_list = []
    for triple_ in negative_list:
        if triple_[1] not in "相克":
            target = triple_[2]
            target_list.append(entity2id_dict[target])

    negative_triple_frequency = [] #用于存储负样本
    for source in fruit_and_vegetable_id:
        for i in range(3):
            try:
                relation = random.choice(source_relation_dict[source])
                target = random.choice(target_list)
                triple_middle = []
                triple_middle.append(source)
                triple_middle.append(target)
                triple_middle.append(relation)
                if triple_middle not in train_triple_list:
                    negative_triple_frequency.append(triple_middle)
            except KeyError:
                pass

    print(negative_triple_frequency)
    print("len(negative_triple_frequency):", len(negative_triple_frequency))
    return negative_triple_frequency
    # frenquency_target = collections.Counter(target_list)
    # print(negative_list)
    # print(frenquency_target)
    # for target in frenquency_target:
    #     print(target)


def random_negative_sample():
    with open("../process_to_OpenKE_format/train2id.txt", encoding='utf-8', mode='r') as f:
        fl = f.readlines()

    train_pos_list = []
    all_triple_set = set()
    for line in fl:
        words = line.split()
        try:
            triple_middle = []
            triple_middle.append(int(words[0]))
            triple_middle.append(int(words[1]))
            triple_middle.append(int(words[2]))
            train_pos_list.append(triple_middle)
            all_triple_set.add(str(triple_middle))
        except IndexError:
            pass

    neg_triple_list = []
    count = 0
    for triple_m in train_pos_list:
        # print(count)
        count += 1
        if count > 540:
            break
        triple = random.choice(train_pos_list)

        rand_triple = random.choice(train_pos_list)
        neg_triple = []
        neg_triple.append(triple[0])
        neg_triple.append(rand_triple[1])
        neg_triple.append(triple[2])
        while str(neg_triple) in all_triple_set:  # 若构造的三元组在知识图谱中含有，则重选。
            rand_triple = random.choice(train_pos_list)
            neg_triple = []
            neg_triple.append(triple[0])
            neg_triple.append(triple[1])
            neg_triple.append(rand_triple[2])
        neg_triple_list.append(neg_triple)
    # with open("./food//neg_triple_valid_food", encoding='utf-8', mode='w') as fw:  # 训练样本
    #     json.dump(neg_triple_list, fw)
    print(len(neg_triple_list))
    return neg_triple_list

if __name__ == '__main__':
    overall_construct_negative_list = []
    # overall_construct_negative_list.extend(sample_from_rumor())  # 真实谣言三元组
    diff_list = construct_from_different_class()
    print(len(diff_list))
    overall_construct_negative_list.extend(diff_list)  # 根据不同类别相互之间功能构造的negative三元组
    # 加一些随机采样的样本
    # rand_list = random_negative_sample()
    # print(len(rand_list))
    # overall_construct_negative_list.extend(rand_list)

    # quit()
    # overall_construct_negative_list.extend(construct_by_frequency())  # 谣言中的高频词三元组
    # 从中分出一部分给test
    random.shuffle(overall_construct_negative_list)
    valid_list = overall_construct_negative_list[-1000:]  # 分出1000个给test
    test_list = overall_construct_negative_list[-1540:-1000]
    train_list = overall_construct_negative_list[:-2000]
    with open("./food/neg_triple_train_food", encoding='utf-8', mode='w') as fw: #存储所有的构造出的负样本三元组，包括谣言三元组，不同类别之间互相构造的三元组，和谣言中高频率词三元组
        json.dump(train_list, fw)

    with open("./food/neg_triple_valid_food", encoding='utf-8', mode='w') as fw:
        json.dump(valid_list, fw)

    with open("./food/neg_triple_test_food", encoding='utf-8', mode='w') as fw:
        json.dump(test_list, fw)

    print(len(overall_construct_negative_list))  # 6445
    print(len(train_list))  # 5445
    print(len(valid_list))  # 1000
    print(len(test_list))

