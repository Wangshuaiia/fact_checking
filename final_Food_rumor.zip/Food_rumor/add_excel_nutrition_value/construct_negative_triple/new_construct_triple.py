'''
2020.1.15
构造食物数据集的三元组
'''

import random
import json

# 方法一：
# # 随机负采样

with open("../process_to_OpenKE_format/valid2id.txt", encoding='utf-8', mode='r') as f:
    fl = f.readlines()

train_pos_list = []
all_triple_set = set()
for line in fl:
    words = line.split()
    try:
        triple_middle = []
        triple_middle.append(int(words[0]))
        triple_middle.append(int(words[1]))
        triple_middle.append(int(words[2]))
        train_pos_list.append(triple_middle)
        all_triple_set.add(str(triple_middle))
    except IndexError:
        pass


neg_triple_list = []
count = 0
for triple_m in train_pos_list:
    print(count)
    count += 1
    if count > 540:
        break
    triple = random.choice(train_pos_list)

    rand_triple = random.choice(train_pos_list)
    neg_triple = []
    neg_triple.append(triple[0])
    neg_triple.append(rand_triple[1])
    neg_triple.append(triple[2])
    while str(neg_triple) in all_triple_set:  # 若构造的三元组在知识图谱中含有，则重选。
        rand_triple = random.choice(train_pos_list)
        neg_triple = []
        neg_triple.append(triple[0])
        neg_triple.append(triple[1])
        neg_triple.append(rand_triple[2])
    neg_triple_list.append(neg_triple)
with open("./food//neg_triple_valid_food", encoding='utf-8', mode='w') as fw:  # 训练样本
    json.dump(neg_triple_list, fw)
print(len(neg_triple_list))

# neg_triple_list = []
# for triple in all_triple[:59071]:
#     rand_triple = random.choice(all_triple)
#     neg_triple = []
#     neg_triple.append(triple[0])
#     neg_triple.append(rand_triple[1])
#     neg_triple.append(triple[2])
#     while neg_triple in all_triple:  # 若构造的三元组在知识图谱中含有，则重选。
#         rand_triple = random.choice(all_triple)
#         neg_triple = []
#         neg_triple.append(triple[0])
#         neg_triple.append(triple[1])
#         neg_triple.append(rand_triple[2])
#     neg_triple_list.append(neg_triple)
# with open("neg_triple_test", encoding='utf-8', mode='w') as fw:  # test 样本
#     json.dump(neg_triple_list, fw)
# print(len(neg_triple_list))
#
# neg_triple_list = []
# for triple in all_triple[:50000]:
#     rand_triple = random.choice(all_triple)
#     neg_triple = []
#     neg_triple.append(triple[0])
#     neg_triple.append(rand_triple[1])
#     neg_triple.append(triple[2])
#     while neg_triple in all_triple:  # 若构造的三元组在知识图谱中含有，则重选。
#         rand_triple = random.choice(all_triple)
#         neg_triple = []
#         neg_triple.append(triple[0])
#         neg_triple.append(triple[1])
#         neg_triple.append(rand_triple[2])
#     neg_triple_list.append(neg_triple)
# with open("neg_triple_valid", encoding='utf-8', mode='w') as fw:  # valid 样本
#     json.dump(neg_triple_list, fw)
# print(len(neg_triple_list))


