'''
构造few-shot 的测试集，从测试集和验证集中找含有few-shot-food-list 的三元组，作为few-shot的测试集
Date：2019.12.10
@author：Shuai Wang
'''
import json
entity2id_dict = dict()
# relation2id_dict = dict()
# source_relation_dict = dict() #这个词典用于存储source和哪些relation相连接
# train_triple_list = []  # 这个用于存储美食天下中用于训练的 triple
# 读取字典
with open("../process_to_OpenKE_format//entity2id.txt", encoding='utf-8', mode='r') as f:
    fl = f.readlines()

    for line in fl:
        words = line.split()
        try:
            entity2id_dict[words[0]] = words[1]
        except IndexError:
            pass
with open('few_shot_food_list', encoding='utf-8', mode='r') as f:
    few_shot_food_list = json.load(f)
few_shot_food_list_id = []
for food in few_shot_food_list:
    few_shot_food_list_id.append(entity2id_dict[food])
# print(few_shot_food_list_id)
# 存储 few_shot_food_list_id
with open('few_shot_food_list_id', encoding='utf-8', mode='w') as fw:
    json.dump(few_shot_food_list_id, fw)

def few_shot_food_triple_construct():
    ''' 使用测试集，构造few-shot的测试样本 '''
    # 读取few-shot list
    with open('../few_shot_learning//few_shot_food_list_id', encoding='utf-8', mode='r') as f:
        few_shot_food_list_id = json.load(f)
    # 从测试集中找
    # 负样本
    with open("../construct_negative_triple//all_rumor_train2id_convert_relation.txt", encoding='utf-8', mode='r') as f:
        test_neg_list_read_from_file = f.readlines()
    print(test_neg_list_read_from_file)
    print(len(test_neg_list_read_from_file))
    few_shot_neg_list = []
    for line in test_neg_list_read_from_file:
        words = line.split()
        try:
            triple_middle = []
            triple_middle.append(words[0])
            triple_middle.append(words[1])
            triple_middle.append(words[2])
            if words[0] in few_shot_food_list_id:
                few_shot_neg_list.append(triple_middle)
        except IndexError:
            pass
    print(few_shot_neg_list)
    print("len(few_shot_neg_list):", len(few_shot_neg_list))
    # 正样本
    with open("../process_to_OpenKE_format/test2id.txt", encoding='utf-8', mode='r') as f:
        test_pos_list_read_from_file = f.readlines()
    print(len(test_pos_list_read_from_file))
    # test_pos_list_middle = random.sample(test_pos_list_read_from_file, len(test_neg_list))   # 从中随机采样出相等的
    few_shot_pos_list = []
    for line in test_pos_list_read_from_file:
        words = line.split()
        try:
            triple_middle = []
            triple_middle.append(words[0])
            triple_middle.append(words[1])
            triple_middle.append(words[2])
            if words[0] in few_shot_food_list_id:
                few_shot_pos_list.append(triple_middle)
        except IndexError:
            pass
    print(few_shot_pos_list)
    print(len(few_shot_pos_list))

    # 存储few-shot pos 和 neg
    with open('few_shot_pos_list', encoding='utf-8', mode='w') as fw:
        json.dump(few_shot_pos_list, fw)
    with open('few_shot_neg_list', encoding='utf-8', mode='w') as fw:
        json.dump(few_shot_neg_list, fw)

if __name__ == '__main__':
    few_shot_food_triple_construct()
