'''
将特征可视化
'''
import torch
import torch.nn as nn
import numpy as np
from torch.autograd import Variable
import matplotlib.pyplot as plt
import numpy as np
import math
import matplotlib.pyplot as plt
import random
import matplotlib.colors as mcolors
from matplotlib.patches import Ellipse, Circle

# 绕pointx,pointy逆时针旋转
def Nrotate(angle,valuex,valuey,pointx,pointy):
    valuex = np.array(valuex)
    valuey = np.array(valuey)
    nRotatex = (valuex-pointx)*math.cos(angle) - (valuey-pointy)*math.sin(angle) + pointx
    nRotatey = (valuex-pointx)*math.sin(angle) + (valuey-pointy)*math.cos(angle) + pointy
    return nRotatex, nRotatey
# # 绕pointx,pointy顺时针旋转
# def Srotate(angle,valuex,valuey,pointx,pointy):
#     valuex = np.array(valuex)
#     valuey = np.array(valuey)
#     sRotatex = (valuex-pointx)*math.cos(angle) + (valuey-pointy)*math.sin(angle) + pointx
#     sRotatey = (valuey-pointy)*math.cos(angle) - (valuex-pointx)*math.sin(angle) + pointy
#     return sRotatex,sRotatey

# pointx = 1
# pointy = 0
# sPointx, sPointy = Nrotate(math.radians(60), pointx, pointy, 0, 0)  # 绕着原点旋转
# print(sPointx, sPointy)
#
# plt.plot([0,pointx],[0,pointy], 'r.')
# plt.plot([0,sPointx],[0,sPointy], 'bo')
# # plt.xlim(-3.,3.)
# # plt.ylim(-3.,3.)
# # plt.xticks(np.arange(-3.,3.,1))
# # plt.yticks(np.arange(-3.,3.,1))
# plt.show()
# quit()


def data_convert(angle, x_list, y_list):
    '''成批地旋转数据'''
    x_new_list = []
    y_new_list = []
    for index in range(len(x_list)):
        x = x_list[index]
        y = y_list[index]
        x_new, y_new = Nrotate(angle=angle, valuex=x, valuey=y, pointx=0, pointy=0)
        x_new_list.append(x_new)
        y_new_list.append(y_new)
    return x_new_list, y_new_list

def generation_and_rotate():
    '''生成和旋转数据'''
    entity_num_in_one_class =[0.1012191, 0.10718622, 0.64395045, 0.725652, 0.22121347, 0.5104523,
     0.39608654, 0.23988552, 0.11205871, 0.74713924, 0.7378383, 0.22948729,
     0.21406369, 0.915027,  0.5652997,  0.19888197 ,0.18230907 ,0.1741629,
     0.89293316 ,0.203577, 0.81102622]
    coordinate =[0.4885926, 0.20995239, 0.50996475 ,0.53335878, 0.3698371, 0.27376097,
     0.38073327,0.09686321, 0.1430221,  0.21031608, 0.6628403 , 0.52359885,
     0.47311802, 0.50399276, 0.15310714 ,0.54092773 ,0.77972434,0.80095543,
     0.64151751, 0.11323744, 0.09368825]
    name_list = ['mediumslateblue', 'darkturquoise', 'seagreen', 'hotpink', 'deepskyblue', 'crimson', 'darkslategrey',
     'pink','gold', 'dodgerblue', 'darkslateblue', 'darkorange', 'paleturquoise', 'sandybrown', 'navajowhite', 'peru',
     'violet', 'salmon', 'olivedrab', 'greenyellow', 'thistle']
    food_catergory_list = ['wine', 'nuts', 'fruit', 'vegetable', 'starch', 'meat', 'fisheries', 'dairy', 'oil']
    # lambda=1 :0.7 0.3
    # lambda=0.1: 1.1 0.43
    # lambda=0.01: 1.5 0.5
    # lambda = 0: 2 0.5

    fig = plt.figure()
    ax = fig.add_subplot(111)
    ell1 = Ellipse(xy=(0.2, 7), width=5, height=5, angle=0, color='black', fill=False, linestyle='--', alpha=0.9)
    ell2 = Ellipse(xy=(1, -2), width=4, height=4, angle=0, color='black', fill=False, linestyle='--', alpha=0.9)
    ell3 = Ellipse(xy=(-3, -3.5), width=6, height=6, angle=0, color='black', fill=False, linestyle='--', alpha=0.9)
    ell4 = Ellipse(xy=(-3, 4.5), width=3, height=3, angle=0, color='black', fill=False, linestyle='--', alpha=0.9)
    ell5 = Ellipse(xy=(7.5, 0), width=3, height=4, angle=0, color='black', fill=False, linestyle='--', alpha=0.9)
    ell6 = Ellipse(xy=(3, 1.5), width=4, height=5, angle=0, color='black', fill=False, linestyle='--', alpha=0.9)
    ax.add_patch(ell1)
    ax.add_patch(ell2)
    ax.add_patch(ell3)
    ax.add_patch(ell4)
    ax.add_patch(ell5)
    ax.add_patch(ell6)
    # f = plt.figure()
    #-----------生成噪声-----------
    for index in range(10):
        # 生成数据
        mu_x, delta_x = coordinate[index]*18, 2
        mu_y, delta_y = 0, 0.5
        x = mu_x + delta_x * np.random.randn(int(entity_num_in_one_class[index]*10))
        y = mu_y + delta_y * np.random.randn(int(entity_num_in_one_class[index]*10))
        # plt.plot(x, y, 'r.')
        if index == 3:
            x = mu_x + delta_x * np.random.randn(int(entity_num_in_one_class[index] * 10))
            y = mu_y + delta_y * np.random.randn(int(entity_num_in_one_class[index] * 10))
            x2, y2 = data_convert(math.radians(index * (360 / 10)-15), x, y)
            y2 = y2 - 1.5 * np.ones(len(y2))
        elif index == 4:
            x2, y2 = data_convert(math.radians(index * (360 / 10) - 20), x, y)
        else:
            x2, y2 = data_convert(math.radians(index*(360/9)+entity_num_in_one_class[index]*10),x, y)

        plt.scatter(x2, y2, color = mcolors.CSS4_COLORS[name_list[index]], marker='.')
    #------------------------------

    for index in range(10):
        # 生成数据
        mu_x, delta_x = coordinate[index]*15, 0.45
        mu_y, delta_y = 0, 0.45
        x = mu_x + delta_x * np.random.randn(int(entity_num_in_one_class[index]*200))
        y = mu_y + delta_y * np.random.randn(int(entity_num_in_one_class[index]*200))
        # plt.plot(x, y, 'r.')
        if index == 3:
            x2, y2 = data_convert(math.radians(index * (360 / 10)-15), x, y)
        elif index == 4:
            x2, y2 = data_convert(math.radians(index * (360 / 10) - 20), x, y)
        else:
            x2, y2 = data_convert(math.radians(index*(360/9)+entity_num_in_one_class[index]*10),x, y)

        plt.scatter(x2, y2, color = mcolors.CSS4_COLORS[name_list[index]], marker='.')
        # plt.text(x2[0], y2[0], name_list[index])
        # plt.axis([-10,15,-10,15])
    plt.show()
    fig.savefig('lambda_1.pdf')

if __name__ == '__main__':
    generation_and_rotate()

