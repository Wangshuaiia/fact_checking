import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
# 创建一个点数为 8 x 6 的窗口, 并设置分辨率为 80像素/每英寸
# plt.figure(figsize=(8, 6), dpi=80)
# 柱子的宽度
width = 0.25
# 绘制柱状图, 每根柱子的颜色为紫罗兰色
x_label_1 = range(1,5)
x_label_2 = []
x_label_middle = []

# fig = plt.figure()
figure,ax = plt.subplots()
for i in x_label_1:
    x_label_2.append(i+width)
    x_label_middle.append(i+width/2)
# x_label_2 = [1.35, 2.35, 3.35, 4.35, 5.35]

# Rumor
# y_label_1 = [0.707, 0.796, 0.793, 0.881, 0.883]
# y_label_2 = [0.726, 0.831, 0.829, 0.901, 0.908]

# FB15K
# y_label_1 = [0.962, 0.948, 0.943, 0.970, 0.965]
# y_label_2 = [0.967, 0.957, 0.953, 0.973, 0.977]
# FOOD
# y_label_1 = [0.784, 0.845, 0.840, 0.916, 0.923]
# y_label_2 = [0.803, 0.864, 0.858, 0.925, 0.936]
y_label_1 = [0.784, 0.845, 0.840, 0.916]
y_label_2 = [0.803, 0.864, 0.858, 0.925]

p2 = plt.bar(x_label_1, y_label_2, width, label="num", color="orange")
p2 = plt.bar(x_label_2, y_label_1, width, label="num", color="g")
# plt.xlim((-5, 5))
# 在柱状图上显示具体数值, ha参数控制水平对齐方式, va控制垂直对齐方式
# for index in range(5):
#     if index == 3:
#         plt.text(x_label_1[index], y_label_2[index] + 0.01, y_label_2[index], ha='center', va='top')
#         plt.text(x_label_2[index]+0.05, y_label_1[index]+0.008, y_label_1[index], ha='center', va='top')
#     else:
#         plt.text(x_label_1[index], y_label_2[index]+0.01, y_label_2[index], ha='center', va='top')
#         plt.text(x_label_2[index]+0.03, y_label_1[index]+0.01, y_label_1[index], ha='center', va='top')

# plt.ylim((0.75, 1))
plt.ylim((0.9, 1))
# plt.xticks(['a'])
method_name_list = ['TransE', 'DistMult', 'Analog', 'A2N', 'Our']
# font2 = {'family' : 'Arial',
# 'weight' : 'normal',
# 'size'   : 14,
# }
plt.xticks(x_label_middle, method_name_list)
# plt.tick_params(labelsize=13,family='Arial')

plt.tick_params(labelsize=22)
labels = ax.get_xticklabels() + ax.get_yticklabels()
[label.set_fontname('Arial') for label in labels]
# [label.set_fontname('Times New Roman') for label in labels]

# 设置横轴标签
# plt.xlabel('food occurrence frequency')
# 设置纵轴标签
# plt.ylabel('AUC')

font1 = {'family' : 'Arial',
'weight' : 'normal',
'size'   : 21,
}
plt.legend(labels = [ 'with PL', 'without PL (original method)'], loc='upper left', prop=font1)

# 添加标题
# plt.title('Distribution of food')

plt.show()
# figure.savefig("bar_FOOD.pdf")
figure.savefig("bar_fb15k.pdf")