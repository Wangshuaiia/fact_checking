'''直接对特征进行可视化'''
from time import time
import matplotlib.pyplot as plt

from sklearn import datasets
from sklearn.manifold import TSNE
import xlrd
import math
import numpy as np
import json
import matplotlib.colors as mcolors

# quit()
def get_data():
    file = "D:\\Dataset\\rumors\\food_Rumor\\food_nutrition.xls"
    wb = xlrd.open_workbook(filename=file)  # 打开文件
    sheet1 = wb.sheet_by_index(0)
    food_name_list = sheet1.col_values(1)  # string
    pl_label_dict = {11: 0, 21: 1, 22: 2, 33: 3, 31: 4, 84: 5, 34: 6, 41: 7, 42: 8, 51: 9, 52: 10, 53: 11, 54: 12, 62: 13, 63: 14,
     71: 15, 85: 16, 32: 17, 61: 18, 81: 19, 83: 20, 82: 21, 86: 22}
    # nutrition_dict = dict()
    # index_dict = dict()
    index2name = dict()
    for i in range(2, len(food_name_list)):
        name = food_name_list[i]
        index2name[i] = name
    nutrition_list = []
    label = []
    for index in range(2, 1285):
        data_middle = sheet1.row_values(index)[3:]
        data_middle = [float(x) for x in data_middle]
        nutrition_list.append(data_middle)
        label.append(pl_label_dict[int(data_middle[-3])])

    data = np.array(nutrition_list)
    x_normed = data / data.max(axis=0)
    label = np.array(label)
    n_samples, n_features = data.shape

    # digits = datasets.load_digits(n_class=6)
    # data = digits.data
    # label = digits.target
    # n_samples, n_features = data.shape
    print(data.shape)

    # quit()
    return x_normed, label, n_samples, n_features


def plot_embedding(data, label, title):
    x_min, x_max = np.min(data, 0), np.max(data, 0)
    data = (data - x_min) / (x_max - x_min)

    fig = plt.figure()
    ax = plt.subplot(111)
    # color_name_list = ['linen', 'mediumturquoise', 'slateblue', 'bisque', 'paleturquoise', 'darkkhaki', 'mediumslateblue', 'gray', 'blue', 'yellow', 'royalblue', 'navajowhite', 'darkgoldenrod', 'midnightblue', 'deepskyblue', 'darkslateblue', 'mistyrose', 'palegoldenrod', 'fuchsia', 'lightsalmon', 'darkgreen', 'aliceblue', 'mediumblue', 'lightblue', 'darkmagenta', 'slategrey', 'lightseagreen', 'lightcoral', 'lime', 'wheat', 'lightgreen', 'orange', 'orchid', 'lightgray', 'plum', 'maroon', 'darksalmon', 'aqua', 'rosybrown', 'lightslategrey', 'mediumvioletred', 'steelblue', 'black', 'darkslategray', 'seashell', 'mediumspringgreen', 'olivedrab', 'snow', 'tomato', 'palegreen', 'khaki', 'white', 'rebeccapurple', 'ivory', 'hotpink', 'powderblue', 'darkred', 'mintcream', 'darkblue', 'lightslategray', 'lightyellow', 'pink', 'darkgrey', 'lightsteelblue', 'tan', 'salmon', 'darkolivegreen', 'burlywood', 'darkgray', 'coral', 'springgreen', 'mediumaquamarine', 'darkseagreen', 'purple', 'blanchedalmond', 'lightpink', 'cadetblue', 'orangered', 'darkslategrey', 'cornsilk', 'sandybrown', 'dimgrey', 'papayawhip', 'aquamarine', 'honeydew', 'gold', 'violet', 'lightcyan', 'grey', 'deeppink', 'peru', 'antiquewhite', 'beige', 'dimgray', 'saddlebrown', 'indianred', 'azure', 'lemonchiffon', 'slategray', 'whitesmoke']
    color_name_list = ['mediumslateblue', 'darkturquoise', 'seagreen', 'hotpink', 'deepskyblue', 'crimson', 'darkslategrey',
     'pink','gold', 'dodgerblue', 'darkslateblue', 'darkorange', 'paleturquoise', 'sandybrown', 'navajowhite', 'peru',
     'violet', 'salmon', 'olivedrab', 'greenyellow', 'thistle', 'yellow', 'royalblue', 'navajowhite', 'darkgoldenrod']
    for i in range(data.shape[0]):
        # plt.text(data[i, 0], data[i, 1], str(label[i]),
        #          color=mcolors.CSS4_COLORS[color_name_list[label[i]]],
        #          fontdict={'weight': 'bold', 'size': 9})
        plt.plot(data[i, 0], data[i, 1], marker='.',
                 color=mcolors.CSS4_COLORS[color_name_list[label[i]]])
    plt.xticks([])
    plt.yticks([])
    plt.title(title)
    return fig


def main():
    data, label, n_samples, n_features = get_data()
    print('Computing t-SNE embedding')
    tsne = TSNE(n_components=2, init='pca', random_state=0)
    t0 = time()
    result = tsne.fit_transform(data)
    fig = plot_embedding(result, label,
                         't-SNE embedding of the digits (time %.2fs)'
                         % (time() - t0))
    plt.show(fig)


if __name__ == '__main__':
    main()
