'''
提取头实体和尾实体的邻居节点，用于谣言可解释性的判断。其中，邻居节点从知识图谱中搜取
数据为谣言的邻居节点数据

这里包含所有的词典： id2entity entity2id  relation2id  id2relation

需要标记的数据有：
1.所有的负样本三元组（580个）
2.从测试集和验证集中选取500个
即，一共标记的数据为1000个
@author: Shuai Wang
@Date:2019.12.9
'''
import json
import re
# 用于替代和删除的字典和list  替代和删除主要是针对谣言转换过来的数据，原KG中的东西不用动
rumor_food_mapping = {'致癌': '防癌抗癌', '牛油': '羊油', '猪油': '羊油',
'茶': '茶叶', '梨子': '丰水梨', '免肉': '兔肉', '食盐': '粗盐', '酒': '白酒', '甜酒': '白酒', '咖啡': '咖啡粉',
'海鲜': '海虾', '鸭': '鸭子', '螯虾': '海虾', '面粉': '荞麦面粉', '蟹': '螃蟹', '湖蟹': '螃蟹', '毛陀蟹': '螃蟹',
'毛蟹': '螃蟹', '糖': '蔗糖', '蜜糖': '蔗糖', '鲫鱼': '乌江鱼', '鱼肉': '乌江鱼'}
delete_list = ['龟肉','鸟肉','雀肉','离路','转基因']

# 读取所有的负向三元组
with open("../../KnowledgeGraph/overall_negative_triple", encoding='utf-8', mode='r') as fw_set:
    f_json_neg = json.load(fw_set)
    fw_set.close()

# 读取测试集中的500个正向三元组
with open("../process_to_OpenKE_format/valid2id.txt", encoding='utf-8', mode='r') as f:
    valid_pos_list_read_from_file = f.readlines()
valid_pos_list = []
for line in valid_pos_list_read_from_file:
    words = line.split()
    try:
        triple_middle = []
        triple_middle.append(words[0])
        triple_middle.append(words[1])
        triple_middle.append(words[2])
        valid_pos_list.append(triple_middle)
    except IndexError:
        pass

# -------------------将所有的三元组转化为id----------------------
fw_set = open("../../crawler/overall_meishiChina_triple_list", encoding='utf-8', mode='r')
positive_list = json.load(fw_set)
fw_set.close()



entity2id_dict = dict()
with open("../process_to_OpenKE_format//entity2id.txt", encoding='utf-8', mode='r') as f:
    fl = f.readlines()
    for line in fl:
        words = line.split()
        try:
            entity2id_dict[words[0]] = words[1]
        except IndexError:
            pass
relation2id_dict = dict()
with open("../process_to_OpenKE_format//relation2id.txt", encoding='utf-8', mode='r') as f:
    fl = f.readlines()
    for line in fl:
        words = line.split()
        try:
            relation2id_dict[words[0]] = words[1]
        except IndexError:
            pass

# -------------------------构造id2relation词典------------------------------------
id2relation_dict = dict()
with open("../process_to_OpenKE_format//relation2id.txt", encoding='utf-8', mode='r') as f:
    fl = f.readlines()

    for line in fl:
        words = line.split()
        try:
            id2relation_dict[words[1]] = words[0]
        except IndexError:
            pass
with open("id2relation_dict", encoding='utf-8', mode='w') as fw:  # 存储 id2relation 字典
    json.dump(id2relation_dict, fw)

with open("../0_food_nutrition_process//id2entity_dict", encoding='utf-8', mode='r') as fr:
    id2entity_dict = json.load(fr)
    # print(id2entity_dict)

positive_triple_id = []  # id形式的triple
for triple_ in positive_list:
    try:
        id_triple = []
        id_triple.append(entity2id_dict[triple_[0]])
        id_triple.append(relation2id_dict[triple_[1]])
        id_triple.append(entity2id_dict[triple_[2].strip()]) #这里一定要注意，三元组的个格式形式是错误的,relation要放在最后
        positive_triple_id.append(id_triple)
    except KeyError:  # 有12个tail是空的，过滤掉就行了，不影响neighbor的搜索
        pass

# --------------在这里对所有的负样本和选580个验证集中的正样本，来构造 头实体 和 尾实体 的neighbor--(top)----------------
'''
@code: 用于做谣言的可解释性，选出所有头实体和尾实体的集合作为evidence的候选集合
@Date:2019.11.27
'''
head_neighbor_dict = dict()  # 头实体的neighbor，即里面存储的都是尾实体
tail_neighbor_dict = dict()  # 尾实体的neighbor，即里面存储的都是头实体
'''构造好head 和tail 的neighbor的字典，在其他程序中直接使用字典即可'''
for triple_ in positive_triple_id:
    source = triple_[0]
    target = triple_[2]
    # relation = triple_[1]
    if source in head_neighbor_dict.keys():
        middle_neighbor = head_neighbor_dict[source]
        if target not in middle_neighbor:
            middle_neighbor.append(target)
            head_neighbor_dict[source] = middle_neighbor
    else:
        head_neighbor_dict[source] = [target]

    if target in tail_neighbor_dict.keys():
        middle_neighbor = tail_neighbor_dict[target]
        if source not in middle_neighbor:
            middle_neighbor.append(source)
            tail_neighbor_dict[target] = middle_neighbor
    else:
        tail_neighbor_dict[target] = [source]
# --------------在这里对所有的负样本和选580个验证集中的正样本，来构造 头实体 和 尾实体 的neighbor--(bottom)---------------
'''
一共1667种食物，1158种功能
'''
# --------------------neighbor的可视化--（top）-----------------------
# print(head_neighbor_dict)
# print(len(tail_neighbor_dict))
# for key in head_neighbor_dict.keys():
#     head_neighbor_list = head_neighbor_dict[key]
#     # print(len(head_neighbor_list))
#     entity_list_middle = []
#     for entity_id in head_neighbor_list:
#         entity_list_middle.append(id2entity_dict[entity_id])
#     print(id2entity_dict[key], entity_list_middle)

# for key in tail_neighbor_dict.keys():
#     tail_neighbor_list = tail_neighbor_dict[key]
#     # print(len(tail_neighbor_list))
#     entity_list_middle = []
#     for entity_id in tail_neighbor_list:
#         entity_list_middle.append(id2entity_dict[entity_id])
#     print(id2entity_dict[key], entity_list_middle)
# --------------------neighbor的可视化--（bottom）-----------------------

# 从知识图谱中搜索neighbor
'''读出数据后，直接查询字典获取neighbor'''
# negative triple
negative_triple_id = []
for triple_ in f_json_neg:  # 在此处替代和删除
    id_triple = []
    if triple_[0] in delete_list:
        continue
    if triple_[0] in rumor_food_mapping.keys():
        # print(triple_[0])
        id_triple.append(entity2id_dict[rumor_food_mapping[triple_[0]]])
    else:
        id_triple.append(entity2id_dict[triple_[0]])
    id_triple.append(relation2id_dict[triple_[1]])  # 边
    if triple_[2] in rumor_food_mapping.keys():
        id_triple.append(entity2id_dict[rumor_food_mapping[triple_[2]]])
    else:
        id_triple.append(entity2id_dict[triple_[2]])
    negative_triple_id.append(id_triple)
# 在这里得到过滤后的id三元组
explainable_verification_negative = []
keyError_count = 0
explainable_triple_dict_evidence_local = dict()

for index in range(len(negative_triple_id)):
    triple_ = negative_triple_id[index]
    head = triple_[0]
    tail = triple_[2]
    try:
        # 获取得到的数据
        # print(triple_, head_neighbor_dict[head], tail_neighbor_dict[tail])
        # 转换为可视化的数据
        triple_vision = [id2entity_dict[triple_[0]], id2relation_dict[triple_[1]], id2entity_dict[triple_[2]]]

        head_list_vision = []
        for entity_id in head_neighbor_dict[head]:
            head_list_vision.append(id2entity_dict[entity_id])
        tail_list_vision = []
        for entity_id in tail_neighbor_dict[tail]:
            tail_list_vision.append(id2entity_dict[entity_id])
        # print(triple_vision, head_list_vision, tail_list_vision)
        explainable_triple_dict_evidence_local[str([triple_[0], triple_[2], triple_[1]])] = [head_list_vision, tail_list_vision]
        if not triple_[1] == relation2id_dict['相克']:
            explainable_verification_negative.append([triple_[0], triple_[2], triple_[1]])
    except KeyError:
        try:
            # print(triple_, head_neighbor_dict[head])
            triple_vision = [id2entity_dict[triple_[0]], id2relation_dict[triple_[1]], id2entity_dict[triple_[2]]]
            head_list_vision = []
            for entity_id in head_neighbor_dict[head]:
                head_list_vision.append(id2entity_dict[entity_id])
            # print(triple_vision, head_list_vision)
            explainable_triple_dict_evidence_local[str([triple_[0], triple_[2], triple_[1]])] = head_list_vision
            if not triple_[1] == relation2id_dict['相克']:
                explainable_verification_negative.append([triple_[0],triple_[2],triple_[1]])
        except KeyError:
            pass
            keyError_count += 1
            # print(id2entity_dict[head], head)
            # print(id2entity_dict[tail], tail)
            # # print(f_json_neg[index])
            # print("------", keyError_count, "-------")

# print(len(negative_triple_id))
# print(len(explainable_verification_negative))
# print(explainable_verification_negative)
# with open("explainable_verification_negative", encoding='utf-8', mode='w') as fw:
#     json.dump(explainable_verification_negative, fw)
# with open("explainable_triple_dict_evidence_local", encoding='utf-8', mode='w') as fw:  # 存储 {三元组： 证据} 字典
#     json.dump(explainable_triple_dict_evidence_local, fw)
# ---构造用于验证的500条正向三元组的neighbor----


# ------------------整理成可以人工判断的形式---（top）------------------------------
# 读取模型给出的neighbor
with open("explainable_triple_dict_server", encoding='utf-8', mode='r') as f:
    explainable_triple_dict = json.load(f)  # 为了保证和服务器上的名字一样，所以起这个名字
# print(explainable_triple_dict)

with open("explainable_id2triple_dict_server", encoding='utf-8', mode='r') as f:
    triple_id2str_dict = json.load(f)
# print(triple_id2str_dict)

# 利用本地的词典
with open("explainable_triple_dict_evidence_local", encoding='utf-8', mode='r') as f:
    explainable_triple_dict_evidence_local = json.load(f)
# print(explainable_triple_dict_evidence_local)

# 整理成人工可以判断的形式
'''<三元组>，<evidence>,
<model给出证据>'''
count_index = 0
for triple_str in explainable_triple_dict.keys():
    evidence = explainable_triple_dict_evidence_local[triple_str]
    model_result = explainable_triple_dict[triple_str]
    triple_word_str = triple_id2str_dict[triple_str]
    # print("triple_str:", triple_str)
    print("count_index -----", count_index, "-----")
    print(evidence)
    print(triple_word_str)
    print(model_result)

    count_index += 1
# --------------正样本给出证据-----(top)--------------

# 读取模型给出的neighbor
with open("pos_explainable_triple_dict_server", encoding='utf-8', mode='r') as f:
    explainable_triple_dict = json.load(f)  # 为了保证和服务器上的名字一样，所以起这个名字
# print(explainable_triple_dict)

with open("pos_explainable_id2triple_dict_server", encoding='utf-8', mode='r') as f:
    triple_id2str_dict = json.load(f)
# print(triple_id2str_dict)
count_index = 0
for triple_str in explainable_triple_dict.keys():

    # evidence = explainable_triple_dict_evidence_local[triple_str]
    # 给出正样本的证据，直接通过head_neighbor和tail_neighbor字典找到证据
    # 通过正则表达式从字符串中提取三元组
    pattern = re.compile("'(.*?)'")
    triple_ = pattern.findall(triple_str)
    h_ = triple_[0]
    t_ = triple_[1]
    r_ = triple_[2]
    try:  # 有4个含有325，或者边的关系是0的，不影响结果
        # print(head_neighbor_dict[h_], tail_neighbor_dict[t_])
        head_list_vision = []
        for entity_id in head_neighbor_dict[h_]:
            head_list_vision.append(id2entity_dict[entity_id])
        tail_list_vision = []
        for entity_id in tail_neighbor_dict[t_]:
            tail_list_vision.append(id2entity_dict[entity_id])
        print(head_list_vision, tail_list_vision)
    except KeyError:
        # print(triple_)
        # print("============================================")
        continue
    triple_word_str = triple_id2str_dict[triple_str]
    print(triple_word_str)
    model_result = explainable_triple_dict[triple_str]

    # print(triple_str)

    print(model_result)
    print("pos_count_index -----", count_index, "-----")
    # print(evidence)
    count_index += 1
# print(len(explainable_triple_dict))  # 正样本的个数
# --------------正样本给出证据-----(bottom)--------------

# ------------------整理成可以人工判断的形式---（bottom）------------------------------
''''''
# ----将mapping_dict 和 delete_list 转化为id的形式，直接用其对数据集进行过滤--（top）-----------
# id_entity_rumor_food_mapping = dict()
# for key in rumor_food_mapping.keys():
#     id_entity_rumor_food_mapping[entity2id_dict[key]] = entity2id_dict[rumor_food_mapping[key]]
# print("id_rumor_food_mapping:", id_entity_rumor_food_mapping)
#
# with open("id_entity_rumor_food_mapping", encoding='utf-8', mode='w') as fw:
#     json.dump(id_entity_rumor_food_mapping, fw)
# ----将mapping_dict 和 delete_list 转化为id的形式，直接用其对数据集进行过滤--（bottom）-----------
