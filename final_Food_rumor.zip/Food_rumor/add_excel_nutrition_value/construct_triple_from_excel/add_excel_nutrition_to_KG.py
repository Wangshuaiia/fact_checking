'''
把excel表格中的营养成分提取出来，按照有无来划分，将其加入进知识图谱。
@author：Shuai Wang
@Date: 2019.12.6
'''
import xlrd
import json
# ------------------------读取excel文件--------------------------------
file = "D:\\Dataset\\rumors\\food_Rumor\\food_nutrition.xls"
wb = xlrd.open_workbook(filename=file)#打开文件
sheet1 = wb.sheet_by_index(0)
food_name_list = sheet1.col_values(1)   # string
index2name = dict()
for i in range(2, len(food_name_list)):
    name = food_name_list[i]
    index2name[i] = name  # 每一个名字都有一个编号
print(index2name)
excel_nutrition_triple_list = []
for column_index in range(3, 20):
    element_list = sheet1.col_values(column_index)
    element_name = element_list[1]
    if element_name == '类别':
        for index in range(2, len(food_name_list)):
            triple = [food_name_list[index], '类别', element_list[index] + '类']
            excel_nutrition_triple_list.append(triple)
            print(triple)
    else:
        element_list_jieduan = element_list[2:]  # 为该类元素排序取出 第300个元素值作为阈值
        element_list_jieduan.sort(reverse=True)
        threshold = element_list_jieduan[300]

        # print(element_name)
        # print(element_list)
        # 直接将三元组的汉字版写在文件中，在 transfer_entity_to_id.py 中将 entity 和 relation 转化为id
        # 此处写的三元组有两种 <食物，含有，元素>, <食物，含有，无元素>
        # print(len(index2name))  #1284
        for index in range(2, len(food_name_list)):
            if element_list[index] > threshold:
                triple = [food_name_list[index], '含有', element_name]
                # print(triple)
            else:
                triple = [food_name_list[index], '含有', '无'+element_name]
                # print(triple)
            excel_nutrition_triple_list.append(triple)
print(len(excel_nutrition_triple_list))  # 21818

with open("excel_nutrition_triple_list", encoding='utf-8', mode='w') as fw:
    json.dump(excel_nutrition_triple_list, fw)




