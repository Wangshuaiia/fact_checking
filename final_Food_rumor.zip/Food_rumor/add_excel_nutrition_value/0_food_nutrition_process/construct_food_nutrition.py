'''
Date:2019.12.9
@author: Shuai Wang
Code: 为谣言检测中的食物构造所含的营养向量。
用所含的营养表示成一个向量
'''

import xlrd
import math
import numpy as np
import json

'''
营养成分表数据处理：
可以利用的数据：
1.类别：需要重新标签（从0开始）。这里不同的类别表示不同的大类，
2.去除所有的括号，并把去除括号后所有的元素的值取平均

'''
# ------------------------读取excel文件--------------------------------
file = "D:\\Dataset\\rumors\\food_Rumor\\food_nutrition.xls"
wb = xlrd.open_workbook(filename=file)#打开文件
sheet1 = wb.sheet_by_index(0)
food_name_list = sheet1.col_values(1)   # string


nutrition_dict = dict()
index_dict = dict()
index2name = dict()
for i in range(2, len(food_name_list)):
    name = food_name_list[i]
    index2name[i] = name

# -------------------------构造id2entity词典------------------------------------
id2entity_dict = dict()
with open("../process_to_OpenKE_format//entity2id.txt", encoding='utf-8', mode='r') as f:
    fl = f.readlines()
    for line in fl:
        words = line.split()
        try:
            id2entity_dict[words[1]] = words[0]
        except IndexError:
            pass
print(id2entity_dict)

def construct_dict():
    two_bits_index = [4,5,6,7,8,17,18]
    three_bits_index = [3,9,12,13,15,16,19]
    special_process_index = [10,11,14]
    for index in range(3,20):
        element_list = sheet1.col_values(index)
        # print(index)
        if index in two_bits_index:
            for value_index in range(2, len(element_list)):
                value = element_list[value_index]
                try:
                    value = math.ceil(value)
                except TypeError:
                    value = math.ceil(float(value))
                if value > 99:
                    value = 99
                if value_index in index_dict.keys():
                    try:
                        index_dict[value_index].append(value)
                    except AttributeError:
                        print(index, value_index)
                        print("quit")
                        quit()
                else:
                    index_dict[value_index] = [value]
                    print("quit()")
                    quit()

        elif index in three_bits_index:
            # print("ok")
            for value_index in range(2, len(element_list)):
                value = element_list[value_index]
                value = math.ceil(value)
                # print(value)
                if value > 999:
                    value = 999
                if value_index in index_dict.keys():
                    index_dict[value_index].append(value)
                else:
                    index_dict[value_index] = [value]
            # print(index, index_dict)

        elif index in special_process_index:
            if index == 10 or index == 11:
                for value_index in range(2, len(element_list)):
                    value = element_list[value_index]
                    value = math.ceil(value * 10)
                    if value > 99:
                        value = 99
                    index_dict[value_index].append(value)
            elif index == 14:
                for value_index in range(2, len(element_list)):
                    value = element_list[value_index]
                    value = math.ceil(value)
                    if value > 9999:
                        value = 9999
                    index_dict[value_index].append(value)


construct_dict()
print(index_dict)
for key in index_dict.keys():
    nutrition_dict[index2name[key]] = index_dict[key]
print(nutrition_dict)
with open("../0_food_nutrition_process//nutrition_dict", encoding='utf-8', mode='w') as fw:
    json.dump(nutrition_dict, fw)
with open("../0_food_nutrition_process//id2entity_dict", encoding='utf-8', mode='w') as fw:
    json.dump(id2entity_dict, fw)

# 直接在这里存储 nutrition_dict 和 id2entity_dict 两个词典
'''
若有对应，直接查
若没有对应的，则：
1.word2vec找相似的取平均
2.找最后一个字。例如：金针菇，属于菇类。可以手动设置几个对应的大类，例如：“菇， 豆，稻，米，玉米，肉， 菜，鸡， 
花，椰，菌，蕉， 羊肉，牛肉， 猪肉，肝， 心， 肺， 蛋， 乳，粉，奶，糖，鱼，虾，蟹，瓜，油，酒，曲，酿”
'''

def retrieve(entity_in):
    key_list = nutrition_dict.keys()
    # 先匹配全字：若包含有全字的直接拿出来
    full_word_contain_list = []
    for key in key_list:
        if entity_in in key:
            full_word_contain_list.append(key)
            break
    # 选取第一个匹配的作为其种类
    if not len(full_word_contain_list) == 0:  # '''----------------可以判断种类------------------'''
        return full_word_contain_list

    # 再匹配最后一个字
    # last_word_list = ['菇，豆，稻，米，肉，骨， 菜，鸡，花，椰，菌，蕉，肝， 心， 肺， 蛋， 乳，粉，奶，糖，鱼，虾，蟹，瓜，油，酒，曲，酿']
    last_word_list = ['菇','豆','稻','米','肉','骨', '菜','鸡','花','椰','菌','蕉','肝','心', '肺', '蛋', '乳','粉','奶','糖','鱼','虾','蟹','瓜','油','酒','曲','酿']

    if entity_in[-1] in last_word_list:  # '''----------------可以判断种类------------------'''
        # print("last word")
        match_last_word_list = []
        for key in key_list:
            if entity_in[-1] in key:
                match_last_word_list.append(key)
                break
        return match_last_word_list

    # 若是俩字： 最后一个字 --》 第一个字
    if len(entity_in) == 2:
        match_last_word_list = []
        match_first_word_list = []
        for key in key_list:
            if entity_in[-1] in key:  # '''----------------可以判断种类------------------'''
                match_last_word_list.append(key)
                break

        if not len(match_last_word_list) == 0:
            return match_last_word_list

        else: #没有符合条件的
            return None
    # 若是三个字：最后俩字 --> 最后一个字 --》 前俩字 -- 》 第一个字
    elif len(entity_in) == 3:
        match_last_two = []
        match_last_one = []
        # match_first_two = []
        # match_first_one = []
        for key in key_list:
            if entity_in[-2:] in key:  # '''----------------可以判断种类------------------'''
                match_last_two.append(key)
                break
            elif entity_in[-1] == key[-1]:  # '''----------------可以判断种类------------------'''
                match_last_one.append(key)
                break

        if not len(match_last_two) == 0:
            return match_last_two
        elif not len(match_last_one) == 0:
            return match_last_one

        else: # 没有符合条件的
            return None
    # 若四个字及其以上， 后俩字 --》前俩字
    elif len(entity_in) > 3:
        match_last_two = []
        # match_first_two = []
        for key in key_list:
            if entity_in[-2:] in key:  # '''----------------可以判断种类------------------'''
                match_last_two.append(key)
                break

        if not len(match_last_two) == 0:
            return match_last_two
        else:
            return None


def judge_full_match(entity_in):
    if entity_in in nutrition_dict.keys():
        return True
    else:
        return False


def get_nutrition(entity_in):
    flag = judge_full_match(entity_in)  # 判断是否能够刚好检索到
    if flag:  # '''----------------可以判断种类------------------'''
        return nutrition_dict[entity_in]
    else:

        food_key_list = retrieve(entity_in)  # 检索相关的食物
        print(food_key_list)
        if food_key_list:
            average = np.zeros(len(nutrition_dict[food_key_list[0]]))
            for key in food_key_list:
                average += np.array(nutrition_dict[key])

            average = average / len(food_key_list)
            return average
        else:
            return None

'''
        给每一个训练或者测试的entity都匹配一个对应的向量
for step, (batch_x, batch_y, batch_target_neighbor, batch_relation_neighbor, batch_nutrition) in enumerate(loader):
 nutrition 传进去的是一个向量
'''
'''
构造一个id2entity的词典，得到id，根据id来查对应的词，根据词找向量，然后得到id对应的向量
'''

def construct_nutrition_content(input_list):
    input_list = [[0,7,14],[30,1,2],[34,2,2]]
    return_nutrition_vector_list = []
    for triple_ in input_list:
        head_id = str(triple_[0])
        entity_str = id2entity_dict[head_id]  # 把id转化为实体
        vector = get_nutrition(entity_str)
        # print(vector)
        # print(type(vector))
        # print(len(vector))
        if vector.any():
            return_nutrition_vector_list.append(vector)
        else:
            return_nutrition_vector_list.append(np.zeros(17))
    return return_nutrition_vector_list

if __name__ == '__main__':
    # test_list = []
    # res_list = construct_nutrition_content(test_list)
    # print(res_list)
    res = get_nutrition("椰汁")
    print("res:", res)

    # # ----------构造食物类别对应的字典-----------
    # id_pl = 0
    # pl_label_dict = dict()
    # for key in nutrition_dict.keys():
    #     pl_label = nutrition_dict[key][-3]
    #     if pl_label not in pl_label_dict.keys():
    #         pl_label_dict[pl_label] = id_pl
    #         id_pl = id_pl + 1
    # print(pl_label_dict)
