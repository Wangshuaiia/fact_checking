'''
记录如何通过
记录如何通过(DistMult) 来改造，得到关于neighbor attention的模型
@author: Shuai Wang
Date: 2019.9.19
'''
def method():
    '''
    // 像姚日恒论文中一样，用一个 trainable matrix 来描述r 和t 之间的作用。

    '''



if __name__ == "__main__":
    '''
    方法：能够获取和集合neighbor attention
        详细方法 1. 得到的是动态的embedding，使用embedding的时候，把其周围的neighbor按照attention聚合起来
        
    最主要问题：
        如何设计双attention机制？稍微复杂一点，用一些先进的技术。dual network; dual attention; bi attention; siamese network; 
    
    要做任务：
        1.如何添加进负样本
        2.如何利用embedding把其变成一个分类任务， 使用什么样的神经网络？
        3.保存和提取distMult初始化的embedding。
        4.attention如何设计？利用设计双attention（relation attention 和 target attention）
    
    创新点：
        提出了一种，relation 和 target dependency 的embedding方法
    
    注意：
        embedding方法可以用Analogical Inference，避免和A2N中重复。且有故事可以讲
    '''