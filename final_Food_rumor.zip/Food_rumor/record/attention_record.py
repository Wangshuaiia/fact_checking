'''
在distMult中添加attention的步骤：
1.数据集整理
    整理出每个节点对应的neighbor，
        1）构造出字典（太慢）
        2）直接作为batch数据传进去（快）
2.从neighbor中取出对应的embedding

3.构造attention
    3.1 先使用双层神经网络构造
    3.2 使用DistMult进行构造
'''
import torch.nn as nn
'''
数据集整理形式：
三元组 label neighbor_nodes neighbor_relations
因为每个三元组训练的时候都需要一系列的neighbors
batch的时候另写函数。例如
n = neighbors
for i in range(10):#有10个neighbors
    b = n[i] #抽取batch中的第一个元素（这个函数形式有待进一步考虑）  b的维度：[8,1] （假如 batch=8）
    neighbor1 = self.embeddings[b] #这样分10次把embedding取出来，取每一个的时候都是batch
最终把邻居表示成一个矩阵

邻居不足，补零问题：
在batch从embedding中取出之后补零，neighbors不够，则不从embedding中取，直接补零到矩阵的最后
'''


