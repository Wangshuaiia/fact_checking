'''
2019.8.10
@author: Shuai Wang
@code:处理原始json数据，从中提取出文本
'''
# import torch
# print(torch.cuda.is_available())
import json
fr_lzy=open("D:\\Dataset\\rumors\\Chinese_Rumor_Dataset-master\\Chinese_Rumor_Dataset-master\\rumors_v170613.json", encoding='utf-8', mode='r').readlines()
fw_1 = open("D:\\Dataset\\rumors\\Chinese_Rumor_Dataset-master\\Chinese_Rumor_Dataset-master\\rumors_text_1", encoding='utf-8', mode='w')
fw_2 = open("D:\\Dataset\\rumors\\Chinese_Rumor_Dataset-master\\Chinese_Rumor_Dataset-master\\rumors_text_2", encoding='utf-8', mode='w')

print(len(fr_lzy))
line_num = 0
for one_json in fr_lzy:
    # print(one_json)
    # print(json.loads(one_json)["rumorText"])
    line_num += 1
    if line_num < 18000:
        fw_1.write(json.loads(one_json)["rumorText"].strip() + "\n")
    else:
        fw_2.write(json.loads(one_json)["rumorText"].strip() + "\n")
fw_1.close()
fw_2.close()
    # quit()

